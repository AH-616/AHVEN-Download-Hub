package com.aven.downloader.ui.browser

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aven.downloader.AvenApp
import com.aven.downloader.data.Settings
import com.aven.downloader.data.StorageSaver
import com.aven.downloader.ui.theme.GlassCard
import com.aven.downloader.ui.theme.GlassColors
import com.aven.downloader.ui.theme.Gold
import com.aven.downloader.ui.theme.glassBorder
import com.aven.downloader.util.Formatters
import com.aven.downloader.util.UrlParser
import kotlinx.coroutines.launch

private val shortcuts = listOf(
    "YouTube" to "https://m.youtube.com",
    "Facebook" to "https://m.facebook.com",
    "Instagram" to "https://www.instagram.com",
    "TikTok" to "https://www.tiktok.com",
    "Google" to "https://www.google.com",
    "Archive.org" to "https://archive.org",
    "GitHub" to "https://github.com",
    "Wikipedia" to "https://www.wikipedia.org"
)

/** IDM-style browser: tabs, address bar that expands, download badge at the top, found-files sheet, long-press menu. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(
    padding: PaddingValues,
    onSupportedVideo: (String) -> Unit,
    onOpenGrabber: () -> Unit,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by AvenApp.instance.settings.flow.collectAsStateWithLifecycle(initialValue = Settings())

    // the activity hosts the WebViews; released again when the browser is left
    remember(context) { BrowserHolder.setHost(context); 0 }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { BrowserHolder.detach() } }

    var field by remember { mutableStateOf(TextFieldValue("")) }
    var editing by remember { mutableStateOf(false) }
    var showSheet by remember { mutableStateOf(false) }
    var showTabs by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var findOpen by remember { mutableStateOf(false) }
    var editorFor by remember { mutableStateOf<Found?>(null) }
    val focus = remember { FocusRequester() }

    val url = BrowserHolder.url
    val curId = BrowserHolder.currentId

    fun toast(m: String) = Toast.makeText(context, m, Toast.LENGTH_SHORT).show()

    fun startDownload(f0: Found) {
        val f = f0.copy(name = BrowserHolder.niceName(f0))
        val target = BrowserHolder.refreshTarget
        if (target != null) {
            BrowserHolder.refreshTarget = null
            scope.launch {
                AvenApp.instance.downloads.replaceLink(target, BrowserHolder.sourceFor(f, f.name), f.type == "hls")
                toast("Link refreshed — download continues")
            }
            return
        }
        if (settings.showDownloadEditor) editorFor = f
        else scope.launch { BrowserHolder.enqueue(f, f.name, 0, 0); toast("Added to Downloads") }
    }

    // another screen asked the browser to open a link ("Refresh link in browser", search results)
    val pending = BrowserHolder.pendingLoad
    LaunchedEffect(pending) {
        pending?.let { BrowserHolder.open(it); BrowserHolder.pendingLoad = null }
    }
    // the page itself started a download: it goes to Downloads, the browser stays open
    val pd = BrowserHolder.pendingDownload
    LaunchedEffect(pd) {
        if (pd != null) { BrowserHolder.pendingDownload = null; startDownload(pd) }
    }
    // <input type=file>
    val chooser = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        BrowserHolder.deliverChooserResult(r.resultCode, r.data)
    }
    val ci = BrowserHolder.chooserIntent
    LaunchedEffect(ci) { if (ci != null) try { chooser.launch(ci) } catch (e: Exception) { BrowserHolder.cancelChooser() } }

    BackHandler {
        when {
            BrowserHolder.customView != null -> BrowserHolder.hideCustom()
            editing -> { editing = false }
            showTabs -> showTabs = false
            findOpen -> { findOpen = false; BrowserHolder.clearFind() }
            BrowserHolder.canBack -> BrowserHolder.back()
            else -> onExit()
        }
    }

    fun beginEdit() {
        field = TextFieldValue(url, TextRange(0, url.length))
        editing = true
    }
    fun go(text: String) { editing = false; BrowserHolder.open(text) }

    Box(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding(), bottom = padding.calculateBottomPadding())) {
        Column(Modifier.fillMaxSize()) {
            // ---- top bar ----
            if (editing) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { editing = false }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Cancel") }
                    TextField(
                        value = field, onValueChange = { field = it }, singleLine = true,
                        placeholder = { Text("Search or type a link") },
                        trailingIcon = { if (field.text.isNotEmpty()) IconButton(onClick = { field = TextFieldValue("") }) { Icon(Icons.Filled.Close, "Clear") } },
                        shape = RoundedCornerShape(26.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = GlassColors.fillStrong, unfocusedContainerColor = GlassColors.fill,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
                        ),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { go(field.text) }),
                        modifier = Modifier.weight(1f).focusRequester(focus)
                    )
                }
                LaunchedEffect(Unit) { focus.requestFocus() }
            } else {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    // tab switcher button (number of tabs)
                    Box(
                        Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).border(BorderStroke(1.5.dp, MaterialTheme.colorScheme.onSurfaceVariant), RoundedCornerShape(10.dp))
                            .clickable { showTabs = true },
                        contentAlignment = Alignment.Center
                    ) { Text("${BrowserHolder.tabs.size}", fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(8.dp))
                    Row(
                        Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(24.dp)).background(GlassColors.fill).border(glassBorder(), RoundedCornerShape(24.dp))
                            .clickable { beginEdit() }.padding(start = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (url.isBlank()) "Search or type a link" else url.removePrefix("https://").removePrefix("http://").removePrefix("www."),
                            Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (url.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                        )
                        IconButton(onClick = { if (BrowserHolder.progress in 1..99) BrowserHolder.stop() else BrowserHolder.reload() }, modifier = Modifier.size(40.dp)) {
                            Icon(if (BrowserHolder.progress in 1..99) Icons.Filled.Close else Icons.Filled.Refresh, "Reload")
                        }
                    }
                    // download button with the number of found files
                    Box(Modifier.size(46.dp).clickable { showSheet = true }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Download, "Found files", tint = if (BrowserHolder.found.isNotEmpty()) Gold else MaterialTheme.colorScheme.onSurfaceVariant)
                        if (BrowserHolder.found.isNotEmpty()) {
                            Box(
                                Modifier.align(Alignment.TopEnd).padding(top = 2.dp, end = 0.dp).size(18.dp).clip(CircleShape).background(Gold),
                                contentAlignment = Alignment.Center
                            ) { Text("${minOf(BrowserHolder.found.size, 99)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold) }
                        }
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Menu") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("New tab") }, onClick = { menu = false; BrowserHolder.newTab(null, true) })
                            DropdownMenuItem(text = { Text("Grabber (scan this page)") }, onClick = { menu = false; onOpenGrabber() })
                            DropdownMenuItem(text = { Text("Back") }, enabled = BrowserHolder.canBack, onClick = { menu = false; BrowserHolder.back() })
                            DropdownMenuItem(text = { Text("Forward") }, enabled = BrowserHolder.canForward, onClick = { menu = false; BrowserHolder.forward() })
                            DropdownMenuItem(text = { Text("Find in page") }, onClick = { menu = false; findOpen = true })
                            DropdownMenuItem(
                                text = { Text(if (BrowserHolder.desktop) "Desktop site: on" else "Desktop site: off") },
                                onClick = { menu = false; BrowserHolder.setDesktop(!BrowserHolder.desktop) }
                            )
                            DropdownMenuItem(text = { Text("Copy link") }, onClick = {
                                menu = false; copyText(context, BrowserHolder.url); toast("Link copied")
                            })
                            DropdownMenuItem(text = { Text("Share link") }, onClick = { menu = false; shareText(context, BrowserHolder.url) })
                            DropdownMenuItem(text = { Text("Start page") }, onClick = { menu = false; BrowserHolder.goHome() })
                            DropdownMenuItem(text = { Text("Clear browsing data") }, onClick = {
                                menu = false; BrowserHolder.clearBrowsingData(); toast("Browsing data cleared")
                            })
                            DropdownMenuItem(text = { Text("Exit browser") }, onClick = { menu = false; onExit() })
                        }
                    }
                }
            }
            if (BrowserHolder.progress in 1..99) {
                LinearProgressIndicator(
                    progress = { BrowserHolder.progress / 100f },
                    modifier = Modifier.fillMaxWidth().height(2.dp), color = Gold, trackColor = Color.Transparent
                )
            } else Spacer(Modifier.height(2.dp))

            if (findOpen) FindBar(onClose = { findOpen = false; BrowserHolder.clearFind() })

            BrowserHolder.refreshTarget?.let {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp).clip(RoundedCornerShape(14.dp)).background(Gold.copy(alpha = 0.18f)).padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Refresh link: open the page, play the file, then pick it from the download button at the top.", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { BrowserHolder.refreshTarget = null }) { Text("Cancel") }
                }
            }

            // ---- page ----
            Box(Modifier.weight(1f).fillMaxWidth()) {
                key(curId) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { _ ->
                            val v = BrowserHolder.currentView()!!
                            (v.parent as? ViewGroup)?.removeView(v)
                            v
                        }
                    )
                }
                if (url.isBlank() || url == "about:blank") StartPage(onOpen = { BrowserHolder.open(it) })

                val supported = UrlParser.isKnownVideoHost(url) &&
                    (UrlParser.isYoutubeSingleVideo(url) || !UrlParser.isYoutube(url))
                if (supported) {
                    Row(
                        Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 12.dp)
                            .clip(RoundedCornerShape(50)).background(Gold).clickable { onSupportedVideo(url) }
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Download, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Download video", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // expanded address bar: suggestions under the field
        if (editing) {
            Column(
                Modifier.fillMaxSize().padding(top = 64.dp).background(MaterialTheme.colorScheme.background).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (field.text.isNotBlank()) {
                    GlassCard(Modifier.fillMaxWidth(), onClick = { go(field.text) }) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Search, null, tint = Gold)
                            Spacer(Modifier.width(12.dp))
                            Text(field.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                Text("Quick links", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                shortcuts.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { (n, u) -> GlassCard(Modifier.weight(1f), onClick = { go(u) }) { Text(n, Modifier.padding(14.dp), fontWeight = FontWeight.Medium) } }
                    }
                }
            }
        }

        if (showTabs) TabSwitcher(onClose = { showTabs = false })
    }

    if (showSheet) {
        ModalBottomSheet(onDismissRequest = { showSheet = false }, containerColor = MaterialTheme.colorScheme.surface) {
            FoundSheet(
                onClose = { showSheet = false },
                onPick = { showSheet = false; startDownload(it) },
                onDownloadAll = { list ->
                    showSheet = false
                    scope.launch {
                        list.forEach { f0 -> val f = f0.copy(name = BrowserHolder.niceName(f0)); BrowserHolder.enqueue(f, f.name, 0, 0) }
                        toast("${list.size} added to Downloads")
                    }
                },
                onGrabber = { showSheet = false; onOpenGrabber() }
            )
        }
    }

    BrowserHolder.contextTarget?.let { t ->
        ContextMenuDialog(
            t, onDismiss = { BrowserHolder.contextTarget = null },
            onAction = { a, value ->
                BrowserHolder.contextTarget = null
                when (a) {
                    "tab" -> BrowserHolder.newTab(value, true, curId)
                    "bgtab" -> { BrowserHolder.newTab(value, false, curId); toast("Opened in background tab") }
                    "editor" -> startDownloadFromUrl(value, url) { startDownload(it) }
                    "copy" -> { copyText(context, value); toast("Copied") }
                    "share" -> shareText(context, value)
                    "dlimage" -> startDownloadFromUrl(value, url) { startDownload(it) }
                    "lens" -> BrowserHolder.newTab("https://lens.google.com/uploadbyurl?url=" + java.net.URLEncoder.encode(value, "UTF-8"), true, curId)
                }
            }
        )
    }

    editorFor?.let { f ->
        DownloadEditorDialog(
            found = f,
            defaultParts = settings.parts,
            onDismiss = { editorFor = null },
            onConfirm = { name, parts, size ->
                editorFor = null
                scope.launch { BrowserHolder.enqueue(f, name, parts, size); toast("Added to Downloads") }
            }
        )
    }
}

private fun startDownloadFromUrl(u: String, referer: String, go: (Found) -> Unit) {
    val name = com.aven.downloader.net.Net.fileNameFrom(null, u)
    go(Found(u, name, BrowserHolder.typeOf(name, null), referer, "", BrowserHolder.currentId))
}

private fun copyText(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("link", text))
}

private fun shareText(context: Context, text: String) {
    if (text.isBlank()) return
    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
    try { context.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (ignored: Exception) { }
}

@Composable
private fun FindBar(onClose: () -> Unit) {
    var q by remember { mutableStateOf("") }
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = q, onValueChange = { q = it; BrowserHolder.find(it) }, singleLine = true,
            placeholder = { Text("Find in page") }, modifier = Modifier.weight(1f)
        )
        TextButton(onClick = { BrowserHolder.findNext(false) }) { Text("Prev") }
        TextButton(onClick = { BrowserHolder.findNext(true) }) { Text("Next") }
        IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Close") }
    }
}

@Composable
private fun TabSwitcher(onClose: () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Tabs (${BrowserHolder.tabs.size})", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            TextButton(onClick = { BrowserHolder.closeAllTabs(); onClose() }) { Text("Close all") }
            TextButton(onClick = { BrowserHolder.newTab(null, true); onClose() }) { Icon(Icons.Filled.Add, null, tint = Gold); Text("New tab", color = Gold) }
            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Close") }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            gridItems(BrowserHolder.tabs.toList(), key = { it.id }) { t ->
                val on = t.id == BrowserHolder.currentId
                GlassCard(
                    Modifier.fillMaxWidth().height(110.dp).then(if (on) Modifier.border(BorderStroke(2.dp, Gold), RoundedCornerShape(26.dp)) else Modifier),
                    onClick = { BrowserHolder.switchTo(t.id); onClose() }
                ) {
                    Row(Modifier.padding(start = 12.dp, top = 8.dp), verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f).padding(top = 6.dp)) {
                            Text(t.title.ifBlank { if (t.url.isBlank()) "New tab" else t.url }, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                            Text(t.url.removePrefix("https://").removePrefix("http://"), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { BrowserHolder.closeTab(t.id) }, modifier = Modifier.size(36.dp)) { Icon(Icons.Filled.Close, "Close tab", Modifier.size(18.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun StartPage(onOpen: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Browse & download", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Open any site. When it plays a video, audio or offers a file, the download button at the top shows a number. " +
                "Menu → Grabber lists every file on a page.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        shortcuts.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { (name, u) ->
                    GlassCard(Modifier.weight(1f), onClick = { onOpen(u) }) {
                        Text(name, Modifier.padding(18.dp), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ContextMenuDialog(t: ContextTarget, onDismiss: () -> Unit, onAction: (String, String) -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        GlassCard(Modifier.fillMaxWidth(), strong = true) {
            Column(Modifier.padding(vertical = 8.dp)) {
                @Composable
                fun row(label: String, action: String, value: String) {
                    Text(label, Modifier.fillMaxWidth().clickable { onAction(action, value) }.padding(horizontal = 20.dp, vertical = 13.dp))
                }
                t.link?.let { l ->
                    Text(l, Modifier.padding(horizontal = 20.dp, vertical = 8.dp), maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    row("Open in new tab", "tab", l)
                    row("Open in background tab", "bgtab", l)
                    row("Open link in download editor", "editor", l)
                    row("Copy link", "copy", l)
                    row("Share link", "share", l)
                }
                t.image?.let { i ->
                    if (t.link != null) Spacer(Modifier.height(6.dp))
                    row("View image", "tab", i)
                    row("Download image", "dlimage", i)
                    row("Search by image", "lens", i)
                    row("Copy image link", "copy", i)
                    row("Share image link", "share", i)
                }
            }
        }
    }
}

/** "File(s) detected!": every media file the page loaded, with size, resolution and length. */
@Composable
private fun FoundSheet(onClose: () -> Unit, onPick: (Found) -> Unit, onDownloadAll: (List<Found>) -> Unit, onGrabber: () -> Unit) {
    val sizes = remember { mutableStateMapOf<String, Long>() }
    val metas = remember { mutableStateMapOf<String, FoundMeta>() }
    val picked = remember { mutableStateMapOf<String, Boolean>() }
    var multi by remember { mutableStateOf(false) }
    var sort by remember { mutableIntStateOf(0) }   // 0 newest, 1 size, 2 name, 3 type
    val all = BrowserHolder.found.toList()
    val shown = when (sort) {
        1 -> all.sortedByDescending { sizes[it.url] ?: 0L }
        2 -> all.sortedBy { BrowserHolder.niceName(it).lowercase() }
        3 -> all.sortedBy { it.type }
        else -> all
    }
    LaunchedEffect(all.map { it.url }) {
        all.take(30).forEach { f ->
            if (sizes[f.url] == null) { launch { sizes[f.url] = BrowserHolder.probeSize(f) } }
            if (metas[f.url] == null) { launch { metas[f.url] = BrowserHolder.meta(f) } }
        }
    }
    Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 20.dp)) {
        Text("File(s) detected!", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Gold)
        Spacer(Modifier.height(4.dp))
        Text("Tap a file to download it. Play the video first if the list is empty.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = multi, onCheckedChange = { multi = it; if (!it) picked.clear() }, colors = CheckboxDefaults.colors(checkedColor = Gold))
            Text("Select files to download", Modifier.weight(1f))
            if (multi) {
                TextButton(onClick = { shown.forEach { picked[it.url] = true } }) { Text("Select all", color = Gold) }
            }
        }
        if (shown.isEmpty()) {
            Text("No media found on this page yet.", Modifier.padding(vertical = 24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(Modifier.height(360.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.url }) { f ->
                    GlassCard(Modifier.fillMaxWidth(), onClick = { if (multi) picked[f.url] = picked[f.url] != true else onPick(f) }) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (multi) Checkbox(checked = picked[f.url] == true, onCheckedChange = { picked[f.url] = it }, colors = CheckboxDefaults.colors(checkedColor = Gold))
                            else Box(
                                Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) { Text(f.type.take(4).uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Gold) }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                val sz = sizes[f.url]
                                val m = metas[f.url]
                                Text(
                                    listOfNotNull(
                                        if (sz != null && sz > 0) Formatters.bytes(sz) else if (f.type == "hls") "Stream" else null,
                                        m?.resolution?.takeIf { it.isNotEmpty() },
                                        m?.durationSec?.takeIf { it > 0 }?.let { Formatters.duration(it.toLong()) }
                                    ).joinToString(" • ").ifEmpty { "…" },
                                    style = MaterialTheme.typography.bodySmall, color = Gold
                                )
                                Text(BrowserHolder.niceName(f), maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                                Text(f.url, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { BrowserHolder.current?.found?.clear() }) { Text("CLEAR ALL") }
            TextButton(onClick = { sort = (sort + 1) % 4 }) { Text("SORT: " + listOf("Newest", "Size", "Name", "Type")[sort]) }
            if (multi && picked.values.any { it }) {
                Button(
                    onClick = { onDownloadAll(shown.filter { picked[it.url] == true }) },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = MaterialTheme.colorScheme.onPrimary)
                ) { Text("Download (${picked.values.count { it }})") }
            } else TextButton(onClick = onGrabber) { Text("GRABBER", color = Gold) }
            TextButton(onClick = onClose) { Text("CLOSE") }
        }
    }
}

/** IDM-style "Download file info" window. Shown only when Settings → Download editor is on. */
@Composable
fun DownloadEditorDialog(
    found: Found,
    defaultParts: Int,
    onDismiss: () -> Unit,
    onConfirm: (name: String, parts: Int, size: Long) -> Unit
) {
    var name by remember { mutableStateOf(found.name) }
    var parts by remember { mutableFloatStateOf(defaultParts.coerceIn(1, 16).toFloat()) }
    var size by remember { mutableStateOf<Long?>(null) }
    LaunchedEffect(found.url) {
        val p = try {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                com.aven.downloader.net.Net.probe(found.url, BrowserHolder.sourceFor(found, name).headers())
            }
        } catch (e: Exception) { null }
        size = p?.size ?: -1L
        if (name.isBlank() && p != null) name = p.fileName
    }
    val category = StorageSaver.categoryFor(name)
    Dialog(onDismissRequest = onDismiss) {
        GlassCard(Modifier.fillMaxWidth(), strong = true) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Download file info", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Gold)
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("File name") }, modifier = Modifier.fillMaxWidth())
                Text(found.url, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    "Size: " + when { size == null -> "checking…"; size!! > 0 -> Formatters.bytes(size!!); else -> "unknown" },
                    style = MaterialTheme.typography.bodyMedium
                )
                Text("Save to: ${category.folder}", style = MaterialTheme.typography.bodyMedium)
                if (found.type != "hls") {
                    Text("Connections: ${parts.toInt()}", style = MaterialTheme.typography.bodyMedium)
                    Slider(value = parts, onValueChange = { parts = it }, valueRange = 1f..16f, steps = 14)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(
                        onClick = { onConfirm(name.ifBlank { found.name }, parts.toInt(), (size ?: 0L).coerceAtLeast(0)) },
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = MaterialTheme.colorScheme.onPrimary)
                    ) { Text("Download") }
                }
            }
        }
    }
}
