package com.aven.downloader.ui.browser

import android.view.ViewGroup
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.aven.downloader.AvenApp
import com.aven.downloader.data.Settings
import com.aven.downloader.ui.theme.GlassCard
import com.aven.downloader.ui.theme.GlassColors
import com.aven.downloader.ui.theme.Gold
import com.aven.downloader.util.Formatters
import com.aven.downloader.util.UrlParser
import kotlinx.coroutines.launch

/**
 * Grabber tab: paste a page link, the app opens it in a hidden page, plays it for a moment and lists every file it finds
 * (video, audio, subtitles, images, documents, zips ...) with type, resolution, length and size.
 */
@Composable
fun GrabberScreen(padding: PaddingValues, onSupported: (String) -> Unit, onDownloads: () -> Unit) {
    val vm: GrabberViewModel = viewModel()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by AvenApp.instance.settings.flow.collectAsStateWithLifecycle(initialValue = Settings())
    var typeDialog by remember { mutableStateOf(false) }
    var showPage by rememberSaveable { mutableStateOf(false) }
    var field by remember { mutableStateOf(vm.url) }
    var editorFor by remember { mutableStateOf<Found?>(null) }
    var editorGo by remember { mutableStateOf(false) }

    // the activity hosts the page's WebView; released again when this tab is left
    remember(context) { BrowserHolder.setHost(context); 0 }
    DisposableEffect(Unit) { onDispose { BrowserHolder.detach() } }

    // "Refresh link in browser" from Downloads
    val pending = BrowserHolder.pendingLoad
    LaunchedEffect(pending) {
        if (pending != null) {
            BrowserHolder.pendingLoad = null
            field = pending
            vm.start(pending)
        }
    }

    fun toast(m: String) = Toast.makeText(context, m, Toast.LENGTH_SHORT).show()
    fun go() { if (field.isNotBlank()) vm.start(field) }

    fun download(f: Found, goDownloads: Boolean) {
        if (settings.showDownloadEditor) { editorGo = goDownloads; editorFor = f }
        else scope.launch {
            vm.enqueueOne(f, BrowserHolder.niceName(f), 0, (vm.sizes[f.url] ?: 0L).coerceAtLeast(0))
            vm.selected.remove(f.url)
            toast("Added to Downloads")
            if (goDownloads) onDownloads()
        }
    }
    fun downloadSelected(goDownloads: Boolean) {
        val sel = vm.visible().filter { it.url in vm.selected }
        if (sel.size == 1) { download(sel.first(), goDownloads); return }
        scope.launch {
            val n = vm.enqueueSelected()
            toast("$n added to Downloads")
            if (goDownloads) onDownloads()
        }
    }

    val list = vm.visible()
    val (count, bytes) = vm.totalSelected()
    val supported = vm.url.isNotBlank() && UrlParser.isKnownVideoHost(vm.url)

    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding(), bottom = padding.calculateBottomPadding())) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Grabber", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            TextButton(onClick = { typeDialog = true }) { Text("File types", color = Gold) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextField(
                value = field, onValueChange = { field = it }, singleLine = true,
                placeholder = { Text("Paste a page link") },
                trailingIcon = { if (field.isNotEmpty()) IconButton(onClick = { field = "" }) { Icon(Icons.Filled.Close, "Clear") } },
                shape = RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = GlassColors.fillStrong, unfocusedContainerColor = GlassColors.fill,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { go() }),
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { go() }, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(24.dp)).background(Gold)) {
                Icon(Icons.Filled.Refresh, "Grab / refresh", tint = MaterialTheme.colorScheme.onPrimary)
            }
        }
        if (vm.grabbing) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), color = Gold)

        // the page itself (kept alive so players run); hidden by default, open it to press play yourself
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                vm.status.ifEmpty { "Paste a link and press the button" }, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            TextButton(onClick = { showPage = !showPage }) { Text(if (showPage) "Hide page" else "Show page", color = Gold) }
        }
        Box(Modifier.fillMaxWidth().height(if (showPage) 220.dp else 1.dp)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { _ ->
                    val v = BrowserHolder.currentView()!!
                    (v.parent as? ViewGroup)?.removeView(v)
                    v
                }
            )
        }

        if (supported) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp))
                    .background(Gold.copy(alpha = 0.18f)).clickable { onSupported(vm.url) }.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Download, null, tint = Gold)
                Spacer(Modifier.width(8.dp))
                Text("This site is supported: tap to choose quality and download", style = MaterialTheme.typography.bodySmall)
            }
        }

        GlassCard(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = list.isNotEmpty() && count == list.size,
                        onCheckedChange = { vm.selectAll(it) },
                        colors = CheckboxDefaults.colors(checkedColor = Gold)
                    )
                    Text("Select all", Modifier.weight(1f))
                    Checkbox(checked = vm.fullNames, onCheckedChange = { vm.fullNames = it }, colors = CheckboxDefaults.colors(checkedColor = Gold))
                    Text("Full names", style = MaterialTheme.typography.bodySmall)
                }
                Text(
                    "Selected: $count / ${list.size}  •  Size: " + if (bytes > 0) Formatters.bytes(bytes) else "—",
                    style = MaterialTheme.typography.bodySmall
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Link depth: ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    listOf(0, 1, 2).forEach { l ->
                        TextButton(onClick = { vm.level = l }) {
                            Text(
                                if (l == 0) "This page" else "Level $l",
                                color = if (vm.level == l) Gold else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = if (vm.level == l) FontWeight.Bold else FontWeight.Normal,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }

        // one chip per file type that was found, with its count: tap to see only that type
        val counts = vm.typeCounts()
        if (counts.isNotEmpty()) {
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = vm.viewFilter == "all", onClick = { vm.viewFilter = "all" },
                        label = { Text("All (${counts.sumOf { it.second }})") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = MaterialTheme.colorScheme.onPrimary)
                    )
                }
                items(counts) { (k, n) ->
                    FilterChip(
                        selected = vm.viewFilter == k, onClick = { vm.viewFilter = k },
                        label = { Text(k.replaceFirstChar { it.uppercase() } + " ($n)") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = MaterialTheme.colorScheme.onPrimary)
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
        }

        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (list.isEmpty()) item {
                Text(
                    if (vm.grabbing) "Looking for files…" else if (vm.url.isBlank()) "Paste the link of a page above. The Grabber lists the video, audio, subtitle, image, document and zip files it finds there."
                    else "No files of the selected types were found. Open \"Show page\", press play in the page, then press the rescan button below. You can also choose more file types.",
                    Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(list, key = { it.url }) { f ->
                GrabRow(f, vm.sizes[f.url], vm.metas[f.url], f.url in vm.selected, vm.fullNames, { vm.toggleSelect(f.url) }, { download(f, false) })
            }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(modifier = Modifier.weight(1f), enabled = count > 0, onClick = { downloadSelected(false) }) { Text("ADD") }
            Button(
                modifier = Modifier.weight(1f), enabled = count > 0,
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = MaterialTheme.colorScheme.onPrimary),
                onClick = { downloadSelected(true) }
            ) { Text("DOWNLOAD") }
            OutlinedButton(modifier = Modifier.weight(1f), onClick = { if (vm.grabbing) vm.stop() else vm.grab() }) { Text(if (vm.grabbing) "STOP" else "RESCAN") }
        }
    }

    editorFor?.let { f ->
        DownloadEditorDialog(
            found = f.copy(name = BrowserHolder.niceName(f)),
            defaultParts = settings.parts,
            onDismiss = { editorFor = null },
            onConfirm = { name, parts, size, start ->
                editorFor = null
                scope.launch {
                    vm.enqueueOne(f, name, parts, size)
                    vm.selected.remove(f.url)
                    Toast.makeText(context, "Added to Downloads", Toast.LENGTH_SHORT).show()
                    if (start || editorGo) onDownloads()
                }
            }
        )
    }
    if (typeDialog) TypeDialog(vm, onClose = { typeDialog = false })
}

private fun prettyRes(r: String): String {
    val h = r.substringAfter('x', "").toIntOrNull() ?: return r
    return "${h}p ($r)"
}

private fun clock(sec: Int): String {
    val h = sec / 3600; val m = sec % 3600 / 60; val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

@Composable
private fun GrabRow(f: Found, size: Long?, meta: FoundMeta?, checked: Boolean, full: Boolean, onToggle: () -> Unit, onDownload: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), onClick = onToggle) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (f.type == "image") {
                    AsyncImage(model = f.url, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                } else Text((if (f.type == "hls") "m3u8" else f.type).take(4).uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Gold)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                val sizeText = if (size == null) "…" else if (size > 0) Formatters.bytes(size) else if (f.type == "hls") "Stream" else "Unknown size"
                val info = listOfNotNull(
                    meta?.resolution?.takeIf { it.isNotBlank() }?.let { prettyRes(it) },
                    meta?.durationSec?.takeIf { it > 0 }?.let { clock(it) },
                    sizeText
                ).joinToString(" • ")
                Text(info, style = MaterialTheme.typography.bodySmall, color = Gold)
                Text(BrowserHolder.niceName(f), maxLines = if (full) 8 else 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = onDownload) { Icon(Icons.Filled.Download, "Download", tint = Gold) }
            Checkbox(checked = checked, onCheckedChange = { onToggle() }, colors = CheckboxDefaults.colors(checkedColor = Gold))
        }
    }
}

@Composable
private fun TypeDialog(vm: GrabberViewModel, onClose: () -> Unit) {
    var sel by remember { mutableStateOf(vm.types) }
    var custom by remember { mutableStateOf(vm.customExt) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Select file types to grab") },
        text = {
            Column {
                GrabType.values().forEach { t ->
                    Row(
                        Modifier.fillMaxWidth().clickable { sel = if (t in sel) sel - t else sel + t },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = t in sel, onCheckedChange = { sel = if (it) sel + t else sel - t }, colors = CheckboxDefaults.colors(checkedColor = Gold))
                        Text(t.label)
                    }
                }
                if (GrabType.CUSTOM in sel) {
                    OutlinedTextField(
                        value = custom, onValueChange = { custom = it }, singleLine = true,
                        label = { Text("Extensions, e.g. iso, mkv, epub") }, modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.setTypes(sel, custom); onClose() }) { Text("OK", color = Gold) } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
