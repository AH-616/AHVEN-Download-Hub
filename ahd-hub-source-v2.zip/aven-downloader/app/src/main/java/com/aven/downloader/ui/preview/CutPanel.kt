package com.aven.downloader.ui.preview

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.aven.downloader.engine.MediaInfo
import com.aven.downloader.engine.PreviewSource
import com.aven.downloader.ui.theme.GlassCard
import com.aven.downloader.ui.theme.Gold
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Picture at a time of a video, read from its address (only the needed bytes are fetched). */
object FrameGrab {
    fun at(url: String, headers: Map<String, String>, ms: Long): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(url, headers)
            val b = r.getFrameAtTime(ms * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
            Bitmap.createScaledBitmap(b, 320, (320f * b.height / b.width.coerceAtLeast(1)).toInt().coerceAtLeast(1), true)
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (ignored: Exception) { }
        }
    }
}

fun clockText(ms: Long): String {
    val t = (ms / 1000).toInt().coerceAtLeast(0)
    val h = t / 3600; val m = t % 3600 / 60; val s = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

/** "1:46", "0:49", "1:02:03" or plain seconds -> milliseconds, or null when it isn't a time. */
fun parseClock(text: String): Long? {
    val parts = text.trim().split(':')
    if (parts.isEmpty() || parts.size > 3) return null
    var total = 0L
    for (p in parts) total = total * 60 + (p.trim().toLongOrNull() ?: return null)
    return total * 1000
}

/** "Download a part": two picture previews (start and end), a range slider and exact time boxes. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CutPanel(
    info: MediaInfo,
    source: PreviewSource?,
    startMs: Long,
    endMs: Long,
    onChange: (Long, Long) -> Unit,
    onClose: () -> Unit,
    fullBytes: Long = 0L,
    durationMs: Long = info.durationSec * 1000L
) {
    val durMs = durationMs
    val partBytes = if (fullBytes > 0 && durMs > 0) (fullBytes.toDouble() * (endMs - startMs) / durMs).toLong() else 0L
    val frameUrl: String?
    val frameHeaders: Map<String, String>
    when (source) {
        is PreviewSource.Single -> { frameUrl = if (source.hls) null else source.url; frameHeaders = source.headers }
        is PreviewSource.Merged -> { frameUrl = source.videoUrl; frameHeaders = source.headers }
        null -> { frameUrl = null; frameHeaders = emptyMap() }
    }
    var startFrame by remember { mutableStateOf<Bitmap?>(null) }
    var endFrame by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(startMs, frameUrl) {
        if (frameUrl == null) return@LaunchedEffect
        delay(450)
        withContext(Dispatchers.IO) { FrameGrab.at(frameUrl, frameHeaders, startMs) }?.let { startFrame = it }
    }
    LaunchedEffect(endMs, frameUrl) {
        if (frameUrl == null) return@LaunchedEffect
        delay(450)
        withContext(Dispatchers.IO) { FrameGrab.at(frameUrl, frameHeaders, (endMs - 500).coerceAtLeast(0)) }?.let { endFrame = it }
    }

    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.ContentCut, null, tint = Gold)
                Text(
                    "  Download a part · " + clockText(endMs - startMs) + if (partBytes > 0) " · ~" + com.aven.downloader.util.Formatters.bytes(partBytes) else "", Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Close") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FramePreview(startFrame, info.thumbnail, clockText(startMs), Modifier.weight(1f))
                FramePreview(endFrame, info.thumbnail, clockText(endMs), Modifier.weight(1f))
            }
            RangeSlider(
                value = (startMs / 1000f)..(endMs / 1000f),
                onValueChange = { r ->
                    var s = (r.start * 1000).toLong().coerceIn(0, durMs)
                    var e = (r.endInclusive * 1000).toLong().coerceIn(0, durMs)
                    if (e - s < 1000) { if (s != startMs) s = (e - 1000).coerceAtLeast(0) else e = (s + 1000).coerceAtMost(durMs) }
                    onChange(s, e)
                },
                valueRange = 0f..(durMs / 1000f).coerceAtLeast(1f),
                colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TimeBox("Start", startMs, Modifier.weight(1f)) { v -> onChange(v.coerceIn(0, (endMs - 1000).coerceAtLeast(0)), endMs) }
                TimeBox("End", endMs, Modifier.weight(1f)) { v -> onChange(startMs, v.coerceIn(startMs + 1000, durMs)) }
            }
            if (partBytes > 0) Text(
                "Size of this part: about " + com.aven.downloader.util.Formatters.bytes(partBytes) +
                    "  (whole video: " + com.aven.downloader.util.Formatters.bytes(fullBytes) + ")",
                fontWeight = FontWeight.SemiBold, color = Gold
            )
            Text(
                "Only this part is downloaded and the file name says which part. The picture starts at the nearest earlier key frame, so it can begin a moment early. Some videos download whole first and are cut after.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun FramePreview(frame: Bitmap?, fallback: String?, label: String, modifier: Modifier) {
    Box(modifier.aspectRatio(16f / 9f).clip(RoundedCornerShape(14.dp)).background(Color.Black)) {
        if (frame != null) Image(frame.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
        else AsyncImage(model = fallback, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
        Text(
            label, Modifier.align(Alignment.BottomStart).padding(6.dp).background(Color(0x99000000), RoundedCornerShape(8.dp)).padding(horizontal = 6.dp, vertical = 2.dp),
            color = Color.White, style = MaterialTheme.typography.labelMedium
        )
    }
}

@Composable
private fun TimeBox(label: String, ms: Long, modifier: Modifier, onCommit: (Long) -> Unit) {
    var text by remember(ms) { mutableStateOf(clockText(ms)) }
    OutlinedTextField(
        value = text, onValueChange = { text = it }, label = { Text(label) }, singleLine = true, modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { parseClock(text)?.let(onCommit) ?: run { text = clockText(ms) } })
    )
}
