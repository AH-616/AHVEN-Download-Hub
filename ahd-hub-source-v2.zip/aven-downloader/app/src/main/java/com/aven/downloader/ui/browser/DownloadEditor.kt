package com.aven.downloader.ui.browser

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.aven.downloader.data.StorageSaver
import com.aven.downloader.ui.theme.GlassCard
import com.aven.downloader.ui.theme.Gold
import com.aven.downloader.util.Formatters

/**
 * IDM-style "Download file!" window: link (copy / share), file name, size, folder, connections,
 * then ADD (queue) / CANCEL / START. Shown only while Settings → Download editor is on.
 */
@Composable
fun DownloadEditorDialog(
    found: Found,
    defaultParts: Int,
    onDismiss: () -> Unit,
    onConfirm: (name: String, parts: Int, size: Long, start: Boolean) -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(found.name) }
    var parts by remember { mutableFloatStateOf(defaultParts.coerceIn(1, 16).toFloat()) }
    var size by remember { mutableStateOf<Long?>(null) }
    var resumable by remember { mutableStateOf<Boolean?>(null) }
    LaunchedEffect(found.url) {
        val p = try {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                com.aven.downloader.net.Net.probe(found.url, BrowserHolder.sourceFor(found, name).headers())
            }
        } catch (e: Exception) { null }
        size = p?.size ?: -1L
        resumable = p?.ranges
        if (name.isBlank() && p != null) name = p.fileName
    }
    val category = StorageSaver.categoryFor(name)
    Dialog(onDismissRequest = onDismiss) {
        GlassCard(Modifier.fillMaxWidth(), strong = true) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Download file!", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(
                        "Link (Resume: " + when (resumable) { true -> "Yes"; false -> "No"; null -> "…" } + ")",
                        Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium
                    )
                    IconButton(onClick = { copyLink(context, found.url) }) { Icon(Icons.Filled.ContentCopy, "Copy link", tint = Gold) }
                    IconButton(onClick = { shareLink(context, found.url) }) { Icon(Icons.Filled.Share, "Share link", tint = Gold) }
                }
                Text(found.url, maxLines = 4, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Save as") }, modifier = Modifier.fillMaxWidth())
                Text(
                    "Size: " + when { size == null -> "checking…"; size!! > 0 -> Formatters.bytes(size!!); else -> "unknown" },
                    style = MaterialTheme.typography.bodyMedium
                )
                Text("Save to: ${category.folder}", style = MaterialTheme.typography.bodyMedium)
                if (found.type != "hls") {
                    Text("Connections: ${parts.toInt()}", style = MaterialTheme.typography.bodyMedium)
                    Slider(value = parts, onValueChange = { parts = it }, valueRange = 1f..16f, steps = 14)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { onConfirm(name.ifBlank { found.name }, parts.toInt(), (size ?: 0L).coerceAtLeast(0), false) }) { Text("ADD", color = Gold) }
                    Spacer(Modifier.width(4.dp))
                    TextButton(onClick = onDismiss) { Text("CANCEL") }
                    Button(
                        onClick = { onConfirm(name.ifBlank { found.name }, parts.toInt(), (size ?: 0L).coerceAtLeast(0), true) },
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = MaterialTheme.colorScheme.onPrimary)
                    ) { Text("START") }
                }
            }
        }
    }
}

private fun copyLink(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("link", text))
    android.widget.Toast.makeText(context, "Link copied", android.widget.Toast.LENGTH_SHORT).show()
}

private fun shareLink(context: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
    try { context.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (ignored: Exception) { }
}
