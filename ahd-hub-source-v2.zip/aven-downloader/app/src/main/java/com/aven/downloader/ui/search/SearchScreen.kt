package com.aven.downloader.ui.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.aven.downloader.engine.YouTubeFast
import com.aven.downloader.ui.theme.GlassColors
import com.aven.downloader.ui.theme.Gold

/**
 * Search tab: type a word, see YouTube results (All / Videos / Playlist / Channels / Music) and tap the
 * download button. Videos and playlists go to the usual preview screen; a channel opens in the browser.
 */
@Composable
fun SearchScreen(padding: PaddingValues, onDownload: (String) -> Unit, onOpenInBrowser: (String) -> Unit, vm: SearchViewModel = viewModel()) {
    androidx.activity.compose.BackHandler(enabled = vm.stack.isNotEmpty()) { vm.back() }
    val cur = vm.current
    if (cur != null) {
        LaunchedEffect(cur) { vm.ensureLoaded(cur) }
        DetailPage(vm, cur, padding, onDownload, onOpenInBrowser)
        return
    }
    val list = rememberLazyListState()
    val nearEnd by remember { derivedStateOf { val last = list.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0; last >= vm.results.size - 4 } }
    LaunchedEffect(nearEnd, vm.results.size) { if (nearEnd && vm.hasMore && !vm.loading) vm.loadMore() }

    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding())) {
        TextField(
            value = vm.query,
            onValueChange = { vm.query = it },
            singleLine = true,
            placeholder = { Text("Search YouTube") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = { if (vm.query.isNotEmpty()) IconButton(onClick = { vm.query = "" }) { Icon(Icons.Filled.Close, "Clear") } },
            shape = RoundedCornerShape(28.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = GlassColors.fillStrong, unfocusedContainerColor = GlassColors.fill,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.submit() }),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)
        )
        LazyRow(contentPadding = PaddingValues(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(SearchFilter.values().toList()) { f ->
                FilterChip(
                    selected = vm.filter == f, onClick = { vm.setFilter(f) }, label = { Text(f.label) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = MaterialTheme.colorScheme.onPrimary)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                state = list,
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = padding.calculateBottomPadding() + 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (!vm.searched) item {
                    Text(
                        "Type what you want and press search. Tap the download button on a result to choose quality and download.",
                        Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                vm.error?.let { e -> item { Text(e, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.error) } }
                items(vm.results.toList(), key = { it.kind + it.url }) { r ->
                    ResultRow(r, onClick = { if (r.kind == "channel") onOpenInBrowser(r.url) else vm.open(r) }, onDownload = { onDownload(r.url) })
                }
                if (vm.loading && vm.results.isNotEmpty()) item {
                    Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp) }
                }
            }
            if (vm.loading && vm.results.isEmpty()) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Gold)
        }
    }
}

@Composable
private fun ResultRow(r: YouTubeFast.SearchItem, onClick: () -> Unit, onDownload: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        Box {
            AsyncImage(
                model = r.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier
                    .width(if (r.kind == "channel") 84.dp else 150.dp)
                    .height(if (r.kind == "channel") 84.dp else 84.dp)
                    .clip(if (r.kind == "channel") CircleShape else RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )
            if (r.durationSec > 0) {
                Text(
                    duration(r.durationSec),
                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xAA000000)).padding(horizontal = 6.dp, vertical = 2.dp),
                    color = Color.White, fontSize = 11.sp
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(r.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(r.line1, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (r.line2.isNotBlank()) Text(r.line2, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (r.kind != "channel") {
            IconButton(onClick = onDownload, modifier = Modifier.size(46.dp).clip(CircleShape).background(Gold.copy(alpha = 0.2f))) {
                Icon(Icons.Filled.Download, "Download", tint = Gold)
            }
        }
    }
}

private fun duration(sec: Int): String {
    val h = sec / 3600; val m = sec % 3600 / 60; val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}


/** A video to watch inside the app (with a Download button), or a playlist (Download all + its videos). */
@Composable
private fun DetailPage(vm: SearchViewModel, pg: YouTubeFast.SearchItem, padding: PaddingValues, onDownload: (String) -> Unit, onOpenInBrowser: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding())) {
        if (pg.kind == "playlist") {
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.back() }) { Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                Text("Playlist", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        } else {
            val stream = vm.streams[pg.url]
            val err = vm.streamErrors[pg.url]
            Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black), contentAlignment = Alignment.Center) {
                when {
                    stream != null -> VideoPlayer(stream, key = pg.url)
                    err != null -> Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                        Text(err, color = Color.White, style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { onOpenInBrowser(pg.url) }) { Text("Open in browser", color = Gold) }
                    }
                    else -> CircularProgressIndicator(color = Gold)
                }
                IconButton(onClick = { vm.back() }, modifier = Modifier.align(Alignment.TopStart)) {
                    Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                }
            }
        }
        Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(pg.title, fontWeight = FontWeight.Bold, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Text(
                listOf(pg.line1, pg.line2).filter { it.isNotBlank() }.joinToString(" • "),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            androidx.compose.material3.Button(
                onClick = { onDownload(pg.url) },
                modifier = Modifier.fillMaxWidth(),
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Gold, contentColor = MaterialTheme.colorScheme.onPrimary)
            ) { Text(if (pg.kind == "playlist") "Download all" else "Download", fontWeight = FontWeight.Bold) }
        }
        val more: List<YouTubeFast.SearchItem>
        var note: String? = null
        if (pg.kind == "playlist") {
            more = vm.playlists[pg.url].orEmpty()
            note = vm.playlistErrors[pg.url] ?: if (more.isEmpty()) "Loading videos…" else null
        } else more = vm.results.filter { it.kind == "video" && it.url != pg.url }
        LazyColumn(
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = padding.calculateBottomPadding() + 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            note?.let { n -> item { Text(n, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
            items(more, key = { it.url }) { r ->
                ResultRow(r, onClick = { vm.open(r) }, onDownload = { onDownload(r.url) })
            }
        }
    }
}

/** The app's own small player: one stream with picture and sound, played by Android's VideoView (no extra library). */
@Composable
private fun VideoPlayer(url: String, key: String) {
    androidx.compose.runtime.key(key) {
        androidx.compose.ui.viewinterop.AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                android.widget.VideoView(ctx).apply {
                    val mc = android.widget.MediaController(ctx)
                    mc.setAnchorView(this)
                    setMediaController(mc)
                    setVideoURI(android.net.Uri.parse(url), mapOf("User-Agent" to com.aven.downloader.net.Net.MOBILE_UA))
                    setOnPreparedListener { it.isLooping = false; start() }
                    setOnErrorListener { _, _, _ -> true }
                }
            },
            onRelease = { v -> try { v.stopPlayback() } catch (ignored: Exception) { } }
        )
    }
}
