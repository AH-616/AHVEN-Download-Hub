package com.aven.downloader.ui.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.aven.downloader.engine.MediaInfo
import com.aven.downloader.engine.YouTubeFast
import com.aven.downloader.ui.player.AppPlayer
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.automirrored.filled.PlaylistPlay
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.aven.downloader.ui.theme.GlassColors
import com.aven.downloader.ui.theme.Gold

/**
 * Search tab: type a word, see YouTube results (All / Videos / Playlist / Channels / Music) and tap the
 * download button (quality list opens right here). Tapping a channel shows its videos.
 */
@Composable
fun SearchScreen(padding: PaddingValues, onDownload: (String) -> Unit, vm: SearchViewModel = viewModel()) {
    androidx.activity.compose.BackHandler(enabled = vm.stack.isNotEmpty()) { vm.back() }
    val cur = vm.current
    if (cur != null) {
        LaunchedEffect(cur) { vm.ensureLoaded(cur) }
        DetailPage(vm, cur, padding, onDownload)
        return
    }
    val list = rememberLazyListState()
    val nearEnd by remember { derivedStateOf { val last = list.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0; last >= vm.results.size - 4 } }
    LaunchedEffect(nearEnd, vm.results.size) { if (nearEnd && vm.hasMore && !vm.loading) vm.loadMore() }

    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding())) {
        TextField(
            value = vm.query,
            onValueChange = { vm.query = it },
            singleLine = true,
            placeholder = { Text("Search YouTube") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = { if (vm.query.isNotEmpty()) IconButton(onClick = { vm.query = "" }) { Icon(Icons.Filled.Close, "Clear") } },
            shape = RoundedCornerShape(28.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = GlassColors.fillStrong, unfocusedContainerColor = GlassColors.fill,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.submit() }),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)
        )
        LazyRow(contentPadding = PaddingValues(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(SearchFilter.values().toList()) { f ->
                FilterChip(
                    selected = vm.filter == f, onClick = { vm.selectFilter(f) }, label = { Text(f.label) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = MaterialTheme.colorScheme.onPrimary)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                state = list,
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = padding.calculateBottomPadding() + 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (!vm.searched) item {
                    Text(
                        "Type what you want and press search. Tap the download button on a result to choose quality and download.",
                        Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                vm.error?.let { e -> item { Text(e, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.error) } }
                items(vm.results.toList(), key = { it.kind + it.url }) { r ->
                    ResultRow(r, onClick = { if (r.kind == "channel") vm.searchChannel(r.title) else vm.open(r) }, onDownload = { onDownload(r.url) })
                }
                if (vm.loading && vm.results.isNotEmpty()) item {
                    Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp) }
                }
            }
            if (vm.loading && vm.results.isEmpty()) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Gold)
        }
    }
}

@Composable
private fun ResultRow(r: YouTubeFast.SearchItem, onClick: () -> Unit, onDownload: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        Box {
            AsyncImage(
                model = r.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier
                    .width(if (r.kind == "channel") 84.dp else 150.dp)
                    .height(if (r.kind == "channel") 84.dp else 84.dp)
                    .clip(if (r.kind == "channel") CircleShape else RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )
            if (r.kind == "playlist") {
                val n = Regex("^[\\d,.]+").find(r.line2)?.value.orEmpty()
                Column(
                    Modifier.align(Alignment.CenterEnd).width(58.dp).height(84.dp)
                        .clip(RoundedCornerShape(topEnd = 14.dp, bottomEnd = 14.dp)).background(Color(0xB3000000)),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    if (n.isNotEmpty()) Text(n, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.PlaylistPlay, "Playlist", tint = Color.White, modifier = Modifier.size(26.dp))
                }
            }
            if (r.durationSec > 0) {
                Text(
                    duration(r.durationSec),
                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xAA000000)).padding(horizontal = 6.dp, vertical = 2.dp),
                    color = Color.White, fontSize = 11.sp
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(r.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(r.line1, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (r.line2.isNotBlank()) Text(r.line2, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (r.kind != "channel") {
            IconButton(onClick = onDownload, modifier = Modifier.size(46.dp).clip(CircleShape).background(Gold.copy(alpha = 0.2f))) {
                Icon(Icons.Filled.Download, "Download", tint = Gold)
            }
        }
    }
}

private fun duration(sec: Int): String {
    val h = sec / 3600; val m = sec % 3600 / 60; val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}


/** A video to watch inside the app (with Download and a ⋮ About menu), or a playlist (Download all + its videos). */
@Composable
private fun DetailPage(vm: SearchViewModel, pg: YouTubeFast.SearchItem, padding: PaddingValues, onDownload: (String) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var about by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding())) {
        if (pg.kind == "playlist") {
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.back() }) { Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                Text("Playlist", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        } else {
            val src = vm.sources[pg.url]
            val err = vm.streamErrors[pg.url]
            Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black), contentAlignment = Alignment.Center) {
                when {
                    src != null -> androidx.compose.runtime.key(pg.url) { AppPlayer(src, Modifier.fillMaxSize(), onBack = { vm.back() }) }
                    err != null -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                            Text(err, color = Color.White, style = MaterialTheme.typography.bodySmall)
                            Row {
                                TextButton(onClick = { vm.retry(pg) }) { Text("Try again", color = Gold) }
                                TextButton(onClick = { openExternal(context, pg.url) }) { Text("Open in YouTube", color = Gold) }
                            }
                        }
                        IconButton(onClick = { vm.back() }, modifier = Modifier.align(Alignment.TopStart)) {
                            Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                        }
                    }
                    else -> {
                        CircularProgressIndicator(color = Gold)
                        IconButton(onClick = { vm.back() }, modifier = Modifier.align(Alignment.TopStart)) {
                            Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                        }
                    }
                }
            }
        }
        Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(pg.title, fontWeight = FontWeight.Bold, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Text(
                listOf(pg.line1, pg.line2).filter { it.isNotBlank() }.joinToString(" • "),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.Button(
                    onClick = { onDownload(pg.url) },
                    modifier = Modifier.weight(1f),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Gold, contentColor = MaterialTheme.colorScheme.onPrimary)
                ) { Text(if (pg.kind == "playlist") "Download all" else "Download", fontWeight = FontWeight.Bold) }
                IconButton(onClick = { about = true }) { Icon(androidx.compose.material.icons.Icons.Filled.MoreVert, "About") }
            }
        }
        val more: List<YouTubeFast.SearchItem>
        var note: String? = null
        if (pg.kind == "playlist") {
            more = vm.playlists[pg.url].orEmpty()
            val perr = vm.playlistErrors[pg.url]
            note = perr ?: if (more.isEmpty()) "Loading videos…" else null
        } else more = vm.results.filter { it.kind == "video" && it.url != pg.url }
        LazyColumn(
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = padding.calculateBottomPadding() + 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            note?.let { n ->
                item {
                    Column {
                        Text(n, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (vm.playlistErrors.containsKey(pg.url)) TextButton(onClick = { vm.retry(pg) }) { Text("Try again", color = Gold) }
                    }
                }
            }
            items(more, key = { it.url }) { r ->
                ResultRow(r, onClick = { vm.open(r) }, onDownload = { onDownload(r.url) })
            }
        }
    }
    if (about) AboutSheet(pg, vm.infos[pg.url], onDismiss = { about = false })
}

private fun openExternal(context: android.content.Context, url: String) {
    try { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (ignored: Exception) { }
}

/** "About" sheet of a video: title, views, channel, share / copy / open, description. */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun AboutSheet(pg: YouTubeFast.SearchItem, info: MediaInfo?, onDismiss: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.material3.ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("About", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(info?.title ?: pg.title, fontWeight = FontWeight.SemiBold)
            val views = info?.viewCount?.takeIf { it >= 0 }?.let { "%,d views".format(it) }
            val line = listOfNotNull(views, info?.uploadDate?.takeIf { it.isNotBlank() }).joinToString("  •  ")
            if (line.isNotEmpty()) Text(line, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Column {
                Text(info?.uploader ?: pg.line1, fontWeight = FontWeight.SemiBold)
                info?.subscribers?.takeIf { it >= 0 }?.let { Text("%,d subscribers".format(it), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                androidx.compose.material3.OutlinedButton(onClick = {
                    val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, pg.url) }
                    try { context.startActivity(android.content.Intent.createChooser(i, "Share").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (ignored: Exception) { }
                }) { Text("Share") }
                androidx.compose.material3.OutlinedButton(onClick = {
                    val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("link", pg.url))
                    android.widget.Toast.makeText(context, "Link copied", android.widget.Toast.LENGTH_SHORT).show()
                }) { Text("Copy link") }
                androidx.compose.material3.OutlinedButton(onClick = { openExternal(context, pg.url) }) { Text("Open in YouTube") }
            }
            val d = info?.description
            if (info == null) Text("Loading details…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            else if (!d.isNullOrBlank()) Text(d, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
