package com.aven.downloader.ui.downloads

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aven.downloader.AvenApp
import com.aven.downloader.data.DownloadEntity
import com.aven.downloader.download.DownloadManager
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DownloadsViewModel(application: Application) : AndroidViewModel(application) {
    private val aven = application as AvenApp
    private val manager = aven.downloads

    val items: StateFlow<List<DownloadEntity>> = aven.database.downloads().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val summary: StateFlow<DownloadManager.Summary> = manager.summary
    val frags: StateFlow<Map<Long, DownloadManager.FragProgress>> = manager.frags

    fun pause(id: Long) = viewModelScope.launch { manager.pause(id) }
    fun resume(id: Long) = viewModelScope.launch { manager.resume(id) }
    fun cancel(id: Long) = viewModelScope.launch { manager.cancel(id) }
    fun retry(id: Long) = viewModelScope.launch { manager.retry(id) }
    fun redownload(id: Long) = viewModelScope.launch { manager.redownload(id) }
    /** Renames the finished file. [done] gets an error text, or null on success. */
    fun rename(e: DownloadEntity, newName: String, done: (String?) -> Unit) = viewModelScope.launch {
        val clean = newName.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (clean.isEmpty()) return@launch done("Name is empty")
        val uri = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            com.aven.downloader.data.StorageSaver.rename(aven, e.outputUri, clean)
        }
        if (uri == null) done("Could not rename (name already exists or no permission)")
        else { aven.database.downloads().setOutput(e.id, uri.toString(), clean); done(null) }
    }

    /** Copies (or moves) the finished file into a folder chosen by the user. */
    fun copyMove(e: DownloadEntity, tree: android.net.Uri, move: Boolean, done: (String) -> Unit) = viewModelScope.launch {
        val name = e.outputName ?: e.title
        val uri = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            com.aven.downloader.data.StorageSaver.copyTo(aven, e.outputUri, name, tree)
        }
        if (uri == null) return@launch done("Could not copy the file")
        if (move) {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { com.aven.downloader.data.StorageSaver.deleteFile(aven, e.outputUri) }
            aven.database.downloads().setOutput(e.id, uri.toString(), name)
            done("Moved")
        } else done("Copied")
    }

    fun remove(id: Long, deleteFile: Boolean) = viewModelScope.launch { manager.remove(id, deleteFile) }
}
