package com.aven.downloader.ui.search

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aven.downloader.engine.YouTubeFast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.Page

enum class SearchFilter(val label: String, val key: String) {
    ALL("All", "all"), VIDEOS("Videos", "videos"), PLAYLISTS("Playlist", "playlists"),
    CHANNELS("Channels", "channels"), MUSIC("Music", "music_songs")
}

/** YouTube search (NewPipe Extractor, no API key). Results are only links: tapping one opens the normal preview & download flow. */
class SearchViewModel : ViewModel() {
    var query by mutableStateOf("")
    var filter by mutableStateOf(SearchFilter.ALL)
        private set
    val results = mutableStateListOf<YouTubeFast.SearchItem>()
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var searched by mutableStateOf(false)
        private set

    // ---- detail pages (a video to watch, or a playlist with its videos) ----
    /** The pages opened from the results; the last one is shown. Back removes it. */
    val stack = mutableStateListOf<YouTubeFast.SearchItem>()
    val current get() = stack.lastOrNull()
    /** video url -> address of a stream the app's own player can play */
    val streams = mutableStateMapOf<String, String>()
    val streamErrors = mutableStateMapOf<String, String>()
    val playlists = mutableStateMapOf<String, List<YouTubeFast.SearchItem>>()
    val playlistErrors = mutableStateMapOf<String, String>()
    private val loadingDetail = HashSet<String>()

    fun open(item: YouTubeFast.SearchItem) { stack.add(item); ensureLoaded(item) }
    fun back(): Boolean { if (stack.isEmpty()) return false; stack.removeAt(stack.lastIndex); return true }
    fun closeAll() = stack.clear()

    fun ensureLoaded(item: YouTubeFast.SearchItem) {
        if (item.kind == "video" && (streams.containsKey(item.url) || streamErrors.containsKey(item.url))) return
        if (item.kind == "playlist" && (playlists.containsKey(item.url) || playlistErrors.containsKey(item.url))) return
        if (!loadingDetail.add(item.url)) return
        viewModelScope.launch {
            try {
                if (item.kind == "playlist") {
                    val pl = YouTubeFast.fetchPlaylist(item.url, 200)
                    playlists[item.url] = pl.entries.map { e ->
                        YouTubeFast.SearchItem("video", e.url, e.title, e.thumbnail, e.uploader.orEmpty(), "", e.durationSec)
                    }
                } else {
                    val info = YouTubeFast.fetchVideo(item.url)
                    // the player needs one stream that already has picture and sound (YouTube offers up to 720p that way)
                    val best = info.formats.filter { it.hasVideo && it.hasAudio && !it.url.isNullOrBlank() && it.protocol == "https" }
                        .sortedByDescending { if (it.height in 1..720) it.height else 0 }.firstOrNull()
                    if (best?.url != null) streams[item.url] = best.url else streamErrors[item.url] = "This video can't be played inside the app."
                }
            } catch (c: CancellationException) {
                throw c
            } catch (t: Throwable) {
                val m = "Could not load: " + (t.message ?: "no internet or YouTube did not answer")
                if (item.kind == "playlist") playlistErrors[item.url] = m else streamErrors[item.url] = m
            } finally {
                loadingDetail.remove(item.url)
            }
        }
    }

    private var next: Page? = null
    private var activeQuery = ""
    private var job: Job? = null

    val hasMore get() = next != null

    fun setFilter(f: SearchFilter) {
        if (f == filter) return
        filter = f
        if (activeQuery.isNotBlank()) run(activeQuery)
    }

    fun submit() {
        val q = query.trim()
        if (q.isEmpty()) return
        run(q)
    }

    private fun run(q: String) {
        job?.cancel()
        activeQuery = q
        results.clear(); next = null; error = null; searched = true; loading = true
        job = viewModelScope.launch { load(q, null) }
    }

    fun loadMore() {
        val p = next ?: return
        if (loading) return
        loading = true
        job = viewModelScope.launch { load(activeQuery, p) }
    }

    private suspend fun load(q: String, page: Page?) {
        try {
            val r = YouTubeFast.search(q, filter.key, page)
            // ignore a late answer for an older query/filter
            if (q != activeQuery) return
            results.addAll(r.items)
            next = r.next
            if (results.isEmpty()) error = "Nothing found"
        } catch (c: CancellationException) {
            throw c
        } catch (t: Throwable) {
            if (results.isEmpty()) error = "Search failed: " + (t.message ?: "no internet or YouTube did not answer") else next = null
        } finally {
            loading = false
        }
    }
}
