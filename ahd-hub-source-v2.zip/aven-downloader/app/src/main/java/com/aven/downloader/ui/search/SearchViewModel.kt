package com.aven.downloader.ui.search

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aven.downloader.AvenApp
import com.aven.downloader.engine.MediaInfo
import com.aven.downloader.engine.YouTubeFast
import com.aven.downloader.ui.player.PlayerSources
import com.aven.downloader.ui.player.playerSourcesFrom
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.Page

enum class SearchFilter(val label: String, val key: String) {
    ALL("All", "all"), VIDEOS("Videos", "videos"), PLAYLISTS("Playlist", "playlists"),
    CHANNELS("Channels", "channels"), MUSIC("Music", "music_songs")
}

/** YouTube search (NewPipe Extractor, no API key). Results are only links: tapping one opens the normal preview & download flow. */
class SearchViewModel : ViewModel() {
    var query by mutableStateOf("")
        private set
    var filter by mutableStateOf(SearchFilter.ALL)
        private set
    // ---- suggestions while typing, and the words searched before ----
    val suggestions = mutableStateListOf<String>()
    val history = mutableStateListOf<String>()
    private var suggestJob: Job? = null
    private val prefs by lazy { AvenApp.instance.getSharedPreferences("search", android.content.Context.MODE_PRIVATE) }

    init {
        YouTubeFast.warmUp()
        history.addAll(prefs.getString("history", "").orEmpty().split('\n').filter { it.isNotBlank() })
    }

    /** The text field changed: remember it and ask YouTube for suggestions (after a short pause). */
    fun onQuery(text: String) {
        query = text
        suggestJob?.cancel()
        if (text.isBlank()) { suggestions.clear(); return }
        suggestJob = viewModelScope.launch {
            delay(220)
            val list = YouTubeFast.suggestions(text.trim())
            if (query == text) { suggestions.clear(); suggestions.addAll(list) }
        }
    }

    /** Runs a search for [text] (a tapped suggestion / history word). */
    fun searchFor(text: String) { query = text; submit() }

    private fun saveHistory(q: String) {
        history.remove(q); history.add(0, q)
        while (history.size > 20) history.removeAt(history.lastIndex)
        prefs.edit().putString("history", history.joinToString("\n")).apply()
    }

    fun removeHistory(q: String) {
        history.remove(q)
        prefs.edit().putString("history", history.joinToString("\n")).apply()
    }

    fun clearHistory() {
        history.clear()
        prefs.edit().remove("history").apply()
    }

    val results = mutableStateListOf<YouTubeFast.SearchItem>()
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var searched by mutableStateOf(false)
        private set

    // ---- detail pages (a video to watch, or a playlist with its videos) ----
    /** The pages opened from the results; the last one is shown. Back removes it. */
    val stack = mutableStateListOf<YouTubeFast.SearchItem>()
    val current get() = stack.lastOrNull()
    /** video url -> what the app's own player needs (qualities, audio languages) */
    val sources = mutableStateMapOf<String, PlayerSources>()
    /** video url -> details for the About sheet */
    val infos = mutableStateMapOf<String, MediaInfo>()
    val streamErrors = mutableStateMapOf<String, String>()
    /** video url -> the videos YouTube suggests next to it */
    val related = mutableStateMapOf<String, List<YouTubeFast.SearchItem>>()
    val playlists = mutableStateMapOf<String, List<YouTubeFast.SearchItem>>()
    val playlistErrors = mutableStateMapOf<String, String>()
    private val loadingDetail = HashSet<String>()

    fun open(item: YouTubeFast.SearchItem) { stack.add(item); ensureLoaded(item) }
    fun back(): Boolean { if (stack.isEmpty()) return false; stack.removeAt(stack.lastIndex); return true }
    fun closeAll() = stack.clear()

    /** "Try again" after a failed load. */
    fun retry(item: YouTubeFast.SearchItem) {
        streamErrors.remove(item.url); playlistErrors.remove(item.url)
        ensureLoaded(item)
    }

    fun ensureLoaded(item: YouTubeFast.SearchItem) {
        if (item.kind == "video" && (sources.containsKey(item.url) || streamErrors.containsKey(item.url))) return
        if (item.kind == "playlist" && (playlists.containsKey(item.url) || playlistErrors.containsKey(item.url))) return
        if (!loadingDetail.add(item.url)) return
        viewModelScope.launch {
            try {
                if (item.kind == "playlist") {
                    val pl = YouTubeFast.fetchPlaylist(item.url, 200)
                    playlists[item.url] = pl.entries.map { e ->
                        YouTubeFast.SearchItem("video", e.url, e.title, e.thumbnail, e.uploader.orEmpty(), "", e.durationSec)
                    }
                } else {
                    // YouTube sometimes answers late or not at all: one quiet second try before showing an error
                    val info = try { YouTubeFast.fetchVideo(item.url) } catch (e: CancellationException) { throw e } catch (e: Exception) {
                        delay(800); YouTubeFast.fetchVideo(item.url)
                    }
                    infos[item.url] = info
                    related[item.url] = YouTubeFast.relatedOf(item.url)
                    val ps = playerSourcesFrom(info)
                    if (ps != null) sources[item.url] = ps else streamErrors[item.url] = "This video can't be played inside the app."
                }
            } catch (c: CancellationException) {
                throw c
            } catch (t: Throwable) {
                val m = "Could not load: " + (t.message ?: "no internet or YouTube did not answer")
                if (item.kind == "playlist") playlistErrors[item.url] = m else streamErrors[item.url] = m
            } finally {
                loadingDetail.remove(item.url)
            }
        }
    }

    private var next: Page? = null
    private var activeQuery = ""
    private var job: Job? = null

    val hasMore get() = next != null

    /** Tapping a channel result: show that channel's videos (a search for its name). */
    fun searchChannel(name: String) {
        query = name
        filter = SearchFilter.VIDEOS
        startSearch(name)
    }

    fun selectFilter(f: SearchFilter) {
        if (f == filter) return
        filter = f
        if (activeQuery.isNotBlank()) startSearch(activeQuery)
    }

    fun submit() {
        val q = query.trim()
        if (q.isEmpty()) return
        suggestJob?.cancel(); suggestions.clear()
        saveHistory(q)
        startSearch(q)
    }

    private fun startSearch(q: String) {
        job?.cancel()
        activeQuery = q
        results.clear(); next = null; error = null; searched = true; loading = true
        job = viewModelScope.launch { load(q, null) }
    }

    fun loadMore() {
        val p = next ?: return
        if (loading) return
        loading = true
        job = viewModelScope.launch { load(activeQuery, p) }
    }

    private suspend fun load(q: String, page: Page?) {
        try {
            val r = YouTubeFast.search(q, filter.key, page)
            // ignore a late answer for an older query/filter
            if (q != activeQuery) return
            val seen = results.map { it.kind + it.url }.toHashSet()
            results.addAll(r.items.filter { seen.add(it.kind + it.url) })
            next = r.next
            if (results.isEmpty()) error = "Nothing found"
        } catch (c: CancellationException) {
            throw c
        } catch (t: Throwable) {
            if (results.isEmpty()) error = "Search failed: " + (t.message ?: "no internet or YouTube did not answer") else next = null
        } finally {
            loading = false
        }
    }
}
