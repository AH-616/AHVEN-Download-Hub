package com.aven.downloader.ui

/** Texts of the first-install welcome popup and the one-time "What's new" popup after an update. */
object WhatsNew {
    val features = listOf(
        "Download videos and audio from YouTube, Facebook, Instagram, TikTok and 1000+ other sites",
        "Google Drive videos, zip files and documents",
        "Share any link to AHD Hub: pick the quality in a small popup and it downloads in the background",
        "Playlists with the estimated total size, audio language choice, M4A / Opus",
        "Files are sorted into folders (Videos, Music, Documents ...) inside the folder you choose",
        "Grabber: lists every file on a page with type, resolution and size"
    )

    /** Notes for each build; builds without an entry show nothing. */
    fun notesFor(versionCode: Int): List<String>? = when {
        versionCode >= 1 -> listOf(
            "Search tab: search YouTube (All, Videos, Playlists, Channels), watch in the app with quality and audio-language choice, download videos or whole playlists",
            "Downloaded videos and music play inside the app",
            "Downloads: All / Downloading / Finished / Error tabs and a full menu on every item",
            "New liquid-glass look with dark and light themes",
            "Much faster YouTube lookup and download",
            "DNS over HTTPS, Clear cache, and a separate App update section in Settings",
            "Failed downloads: Redownload",
            "Downloads are sorted into folders by file type",
            "In-app updates: new versions can be installed from inside the app",
            "Engine version and date are shown in Settings",
            "Smaller fixes and speed improvements"
        )
        else -> null
    }
}
