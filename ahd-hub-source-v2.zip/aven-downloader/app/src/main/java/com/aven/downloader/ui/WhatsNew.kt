package com.aven.downloader.ui

/** Texts of the first-install welcome popup and the one-time "What's new" popup after an update. */
object WhatsNew {
    val features = listOf(
        "Download videos and audio from YouTube, Facebook, Instagram, TikTok and 1000+ other sites",
        "Download only a part of a video (✂ Cut) from YouTube, Facebook, Instagram and TikTok",
        "Share any link to AHD Hub: pick the quality in a small popup and it downloads in the background",
        "Playlists with the estimated total size, audio language choice, M4A / Opus",
        "Files are sorted into folders (Videos, Music, Documents ...) inside the folder you choose",
        "Built-in player: zoom, night mode, subtitles, audio tracks, HW / SW decoder, background play"
    )

    /** Notes for each build; builds without an entry show nothing. */
    fun notesFor(versionCode: Int): List<String>? = when {
        versionCode >= 1 -> listOf(
            "✂ Cut: download just the part you need. The file name says which part was cut",
            "Fixed Facebook / Instagram videos that had no sound",
            "Stronger in-app player: rotate, fit / fill / stretch / pinch zoom, night mode, subtitles (also from a file), audio tracks, HW / HW+ / SW decoder, background play, swipe for brightness and volume",
            "YouTube search: suggestions, recent searches, real related videos, faster repeat opens",
            "Google Drive: downloads still work when the saved login has expired",
            "Finished file Properties: tap the link or the saved path to copy it",
            "Search tab: search YouTube (All, Videos, Playlists, Channels), watch in the app with quality and audio-language choice, download videos or whole playlists",
            "Downloaded videos and music play inside the app",
            "Downloads: All / Downloading / Finished / Error tabs and a full menu on every item",
            "New liquid-glass look with dark and light themes",
            "Much faster YouTube lookup and download",
            "DNS over HTTPS, Clear cache, and a separate App update section in Settings",
            "Failed downloads: Redownload",
            "Downloads are sorted into folders by file type",
            "In-app updates: new versions can be installed from inside the app",
            "Engine version and date are shown in Settings",
            "Smaller fixes and speed improvements"
        )
        else -> null
    }
}
