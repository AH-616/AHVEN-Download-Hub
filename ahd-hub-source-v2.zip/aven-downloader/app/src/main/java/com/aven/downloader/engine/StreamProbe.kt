package com.aven.downloader.engine

import android.media.MediaMetadataRetriever
import com.aven.downloader.net.Net
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Request
import java.util.concurrent.ConcurrentHashMap

/**
 * Some sites (Instagram, some Facebook videos) tell neither the file size nor the length of a video.
 * This asks the stream itself: size from the HTTP answer, length from the file's own header.
 */
object StreamProbe {
    class Result(val bytes: Long, val durationMs: Long)

    private val cache = ConcurrentHashMap<String, Result>()

    suspend fun probe(f: StreamFormat?): Result? {
        val url = f?.url ?: return null
        if (f.protocol != null && f.protocol != "https" && f.protocol != "http") return null
        cache[url]?.let { return it }
        val headers = f.headers.filterKeys { !it.equals("Accept-Encoding", true) }
        val r = withTimeoutOrNull(15_000) {
            withContext(Dispatchers.IO) { Result(sizeOf(url, headers), lengthOf(url, headers)) }
        } ?: return null
        if (r.bytes <= 0 && r.durationMs <= 0) return null
        cache[url] = r
        return r
    }

    private fun sizeOf(url: String, headers: Map<String, String>): Long = try {
        val b = Request.Builder().url(url).header("Range", "bytes=0-0")
        if (headers.keys.none { it.equals("User-Agent", true) }) b.header("User-Agent", Net.DESKTOP_UA)
        headers.forEach { (k, v) -> b.header(k, v) }
        Net.client.newCall(b.build()).execute().use { resp ->
            val range = resp.header("Content-Range")?.substringAfter('/', "")?.trim()?.toLongOrNull()
            range ?: resp.header("Content-Length")?.toLongOrNull()?.takeIf { resp.code == 200 } ?: 0L
        }
    } catch (e: Exception) {
        0L
    }

    private fun lengthOf(url: String, headers: Map<String, String>): Long {
        val m = MediaMetadataRetriever()
        return try {
            val h = HashMap(headers)
            if (h.keys.none { it.equals("User-Agent", true) }) h["User-Agent"] = Net.DESKTOP_UA
            m.setDataSource(url, h)
            m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            try { m.release() } catch (ignored: Exception) { }
        }
    }
}
