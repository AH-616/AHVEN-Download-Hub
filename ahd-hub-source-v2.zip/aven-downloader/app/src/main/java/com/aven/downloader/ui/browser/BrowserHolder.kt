package com.aven.downloader.ui.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.aven.downloader.AvenApp
import com.aven.downloader.data.StorageSaver
import com.aven.downloader.engine.DirectFiles
import com.aven.downloader.engine.DirectSource
import com.aven.downloader.net.Net
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream

/** One thing the browser saw on a page that can be downloaded. */
data class Found(
    val url: String,
    val name: String,
    /** video | audio | hls | image | subtitle | document | compressed | program | torrent | other */
    val type: String,
    val referer: String,
    val mime: String = "",
    val tabId: Int = -1
) {
    val isMedia get() = type == "video" || type == "audio" || type == "hls"
}

/** Resolution / length of a found media file, when it can be read cheaply. */
data class FoundMeta(val resolution: String = "", val durationSec: Int = 0)

/** One browser tab. Everything the UI shows is compose state. */
class BTab(val id: Int) {
    var web: WebView? = null
    var wrapper: MutableContextWrapper? = null
    var url by mutableStateOf("")
    var title by mutableStateOf("")
    var progress by mutableIntStateOf(100)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var desktop by mutableStateOf(false)
    var blocked by mutableIntStateOf(0)
    /** Media on this page: the "download" button of the browser. */
    val found = mutableStateListOf<Found>()
    /** Everything the page loaded (any file type): used by the Grabber. */
    val resources = mutableStateListOf<Found>()
    val seen = HashSet<String>()
    val probed = HashSet<String>()
    var lastPage = ""
    var parent: Int = -1
}

/** What the user long-pressed: a link and/or an image. */
data class ContextTarget(val link: String?, val image: String?)

/**
 * The in-app browser: a list of tabs, each with its own WebView. The WebViews live here (not in a composable)
 * so pages, scroll position and the list of sniffed files survive switching to other app tabs.
 */
object BrowserHolder {
    private val main = Handler(Looper.getMainLooper())
    private var started = false
    private var nextId = 1
    private var host: Context? = null

    @Volatile private var blockAds = true
    @Volatile private var searchEngine = "google"

    val tabs = mutableStateListOf<BTab>()
    var currentId by mutableIntStateOf(-1)
        private set

    val current: BTab? get() = tabs.firstOrNull { it.id == currentId }

    // ---- state of the current tab (compose-observable) ----
    val url: String get() = current?.url.orEmpty()
    val title: String get() = current?.title.orEmpty()
    val progress: Int get() = current?.progress ?: 100
    val canBack: Boolean get() = current?.canBack ?: false
    val canForward: Boolean get() = current?.canForward ?: false
    val desktop: Boolean get() = current?.desktop ?: false
    val blockedCount: Int get() = current?.blocked ?: 0
    val found: List<Found> get() = current?.found ?: emptyList()
    val resources: List<Found> get() = current?.resources ?: emptyList()

    /** Set by other screens ("Refresh link in browser", search results); consumed by GrabberScreen. */
    var pendingLoad by mutableStateOf<String?>(null)
    /** Set when the page itself started a file download (attachment / unknown mime). */
    var pendingDownload by mutableStateOf<Found?>(null)
    /** Set by "Refresh link in browser": the next file the user picks replaces the link of this failed download. */
    var refreshTarget by mutableStateOf<Long?>(null)
    /** Long-press menu target. */
    var contextTarget by mutableStateOf<ContextTarget?>(null)
    /** A web page asked to choose a file (upload). The screen launches the system picker. */
    var chooserIntent by mutableStateOf<Intent?>(null)
    private var chooserCallback: ValueCallback<Array<Uri>>? = null

    var customView by mutableStateOf<View?>(null)
        private set
    private var customCb: WebChromeClient.CustomViewCallback? = null

    fun requestLoad(u: String) { pendingLoad = u }

    private fun appContext() = AvenApp.instance

    private fun startSettingsWatch() {
        if (started) return
        started = true
        val app = AvenApp.instance
        app.appScope.launch { app.settings.flow.collect { blockAds = it.blockAds; searchEngine = it.searchEngine } }
    }

    // ---------- host (the activity that shows the WebView) ----------
    /** Tells the tabs which Activity they are shown in (dialogs, fullscreen video need it). */
    fun setHost(context: Context) {
        startSettingsWatch()
        var c = context
        while (c is MutableContextWrapper) c = c.baseContext
        val h = if (c is Activity) c else (c as? android.content.ContextWrapper)?.baseContext?.takeIf { it is Activity } ?: appContext()
        host = h
        tabs.forEach { it.wrapper?.baseContext = h }
        if (tabs.isEmpty()) newTab(null, true)
    }

    fun detach() {
        host = null
        tabs.forEach { it.wrapper?.baseContext = appContext() }
    }

    /** The WebView of the shown tab (created on first use). */
    fun currentView(): WebView? = current?.let { ensureWeb(it) }

    // ---------- tabs ----------
    fun newTab(url: String?, foreground: Boolean = true, parent: Int = -1): BTab {
        if (tabs.size >= MAX_TABS) { closeTab(tabs.first { it.id != currentId }.id) }
        val t = BTab(nextId++)
        t.parent = parent
        tabs.add(t)
        if (foreground || currentId < 0) currentId = t.id
        if (!url.isNullOrBlank()) { ensureWeb(t); t.web?.loadUrl(normalize(url)) }
        return t
    }

    fun switchTo(id: Int) { if (tabs.any { it.id == id }) { hideCustom(); currentId = id } }

    fun closeTab(id: Int) {
        val t = tabs.firstOrNull { it.id == id } ?: return
        val idx = tabs.indexOf(t)
        t.web?.let { w ->
            (w.parent as? ViewGroup)?.removeView(w)
            w.stopLoading(); w.destroy()
        }
        t.web = null
        tabs.remove(t)
        if (tabs.isEmpty()) { newTab(null, true); return }
        if (currentId == id) {
            val back = tabs.firstOrNull { it.id == t.parent } ?: tabs[(idx - 1).coerceAtLeast(0).coerceAtMost(tabs.lastIndex)]
            currentId = back.id
        }
    }

    fun closeAllTabs() {
        tabs.toList().forEach { t -> t.web?.let { w -> (w.parent as? ViewGroup)?.removeView(w); w.destroy() }; t.web = null }
        tabs.clear()
        newTab(null, true)
    }

    private fun normalize(input: String): String {
        val t = input.trim()
        return when {
            t.startsWith("http://", true) || t.startsWith("https://", true) || t.startsWith("file:", true) || t.startsWith("about:", true) -> t
            ' ' !in t && '.' in t -> "https://$t"
            else -> searchUrl(t)
        }
    }

    fun searchUrl(q: String): String {
        val e = java.net.URLEncoder.encode(q, "UTF-8")
        return when (searchEngine) {
            "duckduckgo" -> "https://duckduckgo.com/?q=$e"
            "bing" -> "https://www.bing.com/search?q=$e"
            else -> "https://www.google.com/search?q=$e"
        }
    }

    // ---------- the WebView of a tab ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWeb(tab: BTab): WebView {
        tab.web?.let { return it }
        val w = MutableContextWrapper(host ?: appContext()).also { tab.wrapper = it }
        val v = WebView(w)
        tab.web = v
        with(v.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            allowFileAccess = false
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = Net.MOBILE_UA
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(v, true)
        v.addJavascriptInterface(Bridge(tab), "AHD")
        v.setDownloadListener { u, _, cd, mime, _ ->
            if (!u.startsWith("http")) {
                main.post { android.widget.Toast.makeText(appContext(), "This site's download link can't be saved directly. Play it and use the download button.", android.widget.Toast.LENGTH_LONG).show() }
            } else {
                val name = Net.fileNameFrom(cd, u)
                main.post { pendingDownload = Found(u, name, typeOf(name, mime), tab.url, mime.orEmpty(), tab.id) }
            }
        }
        v.setOnLongClickListener { view ->
            val wv = view as WebView
            val hit = wv.hitTestResult
            when (hit.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE, WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE, WebView.HitTestResult.IMAGE_TYPE -> {
                    val msg = Handler(Looper.getMainLooper(), Handler.Callback { m: Message ->
                        val link = m.data?.getString("url")
                        val img = m.data?.getString("src")
                        val l = link?.takeIf { it.startsWith("http") }
                        val i = (img ?: if (hit.type == WebView.HitTestResult.IMAGE_TYPE) hit.extra else null)?.takeIf { it.startsWith("http") }
                        if (l != null || i != null) contextTarget = ContextTarget(l, i)
                        true
                    }).obtainMessage()
                    wv.requestFocusNodeHref(msg)
                    true
                }
                else -> false
            }
        }
        v.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url.toString()
                if (blockAds && !request.isForMainFrame && AdBlock.isBlocked(request.url.host.orEmpty())) {
                    main.post { tab.blocked++ }
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                if (!request.isForMainFrame) sniff(tab, u, request.requestHeaders)
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val s = request.url.scheme.orEmpty()
                return s != "http" && s != "https" && s != "file" && s != "about"
            }

            override fun onPageStarted(view: WebView, u: String, favicon: Bitmap?) {
                tab.url = u
                if (u != tab.lastPage) {
                    tab.lastPage = u
                    tab.found.clear(); tab.resources.clear(); tab.seen.clear(); tab.probed.clear(); tab.blocked = 0
                }
                tab.canBack = view.canGoBack(); tab.canForward = view.canGoForward()
            }

            override fun onPageFinished(view: WebView, u: String) {
                tab.url = u
                tab.canBack = view.canGoBack(); tab.canForward = view.canGoForward()
                if (blockAds) view.evaluateJavascript(
                    "(function(){var s=document.createElement('style');s.innerHTML=\"${AdBlock.HIDE_CSS}\";document.head&&document.head.appendChild(s);})()", null
                )
                view.evaluateJavascript(SCAN_JS, null)
            }

            override fun doUpdateVisitedHistory(view: WebView, u: String, isReload: Boolean) {
                tab.url = u
                tab.canBack = view.canGoBack(); tab.canForward = view.canGoForward()
            }
        }
        v.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, p: Int) { tab.progress = p }
            override fun onReceivedTitle(view: WebView, t: String?) { tab.title = t.orEmpty() }

            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                val a = host as? Activity
                if (a == null) { cb.onCustomViewHidden(); return }
                (a.window.decorView as FrameLayout).addView(
                    view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                )
                customView = view; customCb = cb
            }
            override fun onHideCustomView() = hideCustom()

            // target=_blank / window.open (only after a tap: javaScriptCanOpenWindowsAutomatically is off)
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (!isUserGesture) return false
                val nt = newTab(null, true, tab.id)
                val nv = ensureWeb(nt)
                (resultMsg.obj as WebView.WebViewTransport).webView = nv
                resultMsg.sendToTarget()
                return true
            }
            override fun onCloseWindow(window: WebView) {
                tabs.firstOrNull { it.web === window }?.let { closeTab(it.id) }
            }

            // <input type=file>
            override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                chooserCallback?.onReceiveValue(null)
                chooserCallback = cb
                chooserIntent = try { params.createIntent() } catch (e: Exception) { chooserCallback = null; cb.onReceiveValue(null); null }
                return true
            }

            override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
                // DRM licence requests are fine; camera, microphone and the like are refused (no permission UI yet).
                val ok = request.resources.filter { it == android.webkit.PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID }.toTypedArray()
                if (ok.isNotEmpty()) request.grant(ok) else request.deny()
            }

            override fun onJsAlert(view: WebView, u: String?, message: String?, result: android.webkit.JsResult): Boolean {
                val a = host as? Activity ?: run { result.cancel(); return true }
                android.app.AlertDialog.Builder(a).setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }
            override fun onJsConfirm(view: WebView, u: String?, message: String?, result: android.webkit.JsResult): Boolean {
                val a = host as? Activity ?: run { result.cancel(); return true }
                android.app.AlertDialog.Builder(a).setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }
            override fun onJsPrompt(view: WebView, u: String?, message: String?, default: String?, result: android.webkit.JsPromptResult): Boolean {
                val a = host as? Activity ?: run { result.cancel(); return true }
                val input = android.widget.EditText(a).apply { setText(default.orEmpty()) }
                android.app.AlertDialog.Builder(a).setMessage(message).setView(input)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }
        }
        return v
    }

    fun deliverChooserResult(resultCode: Int, data: Intent?) {
        val cb = chooserCallback ?: return
        chooserCallback = null
        chooserIntent = null
        cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
    }

    fun cancelChooser() {
        chooserCallback?.onReceiveValue(null)
        chooserCallback = null
        chooserIntent = null
    }

    fun hideCustom() {
        val v = customView ?: return
        (v.parent as? ViewGroup)?.removeView(v)
        customView = null
        customCb?.onCustomViewHidden(); customCb = null
    }

    // ---------- navigation ----------
    /** Opens [input] (a link or search words) in the shown tab. */
    fun open(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        val tab = current ?: newTab(null, true)
        ensureWeb(tab).loadUrl(normalize(t))
    }
    fun back() { current?.web?.goBack() }
    fun forward() { current?.web?.goForward() }
    fun reload() { current?.web?.reload() }
    fun stop() { current?.web?.stopLoading() }
    fun goHome() {
        val t = current ?: return
        t.web?.loadUrl("about:blank"); t.web?.clearHistory()
        t.url = ""; t.title = ""; t.found.clear(); t.resources.clear(); t.seen.clear(); t.probed.clear(); t.lastPage = ""
    }

    fun setDesktop(on: Boolean) {
        val t = current ?: return
        t.desktop = on
        t.web?.settings?.apply {
            userAgentString = if (on) Net.DESKTOP_UA else Net.MOBILE_UA
            useWideViewPort = true
            loadWithOverviewMode = on
        }
        t.web?.reload()
    }

    fun find(q: String) { current?.web?.findAllAsync(q) }
    fun findNext(forward: Boolean) { current?.web?.findNext(forward) }
    fun clearFind() { current?.web?.clearMatches() }

    fun clearBrowsingData() {
        tabs.forEach { it.web?.apply { clearCache(true); clearHistory(); clearFormData() } }
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
    }

    fun clearCache() { tabs.forEach { it.web?.clearCache(true) } }

    fun userAgent(): String = current?.web?.settings?.userAgentString ?: Net.MOBILE_UA
    fun cookieFor(u: String): String = try { CookieManager.getInstance().getCookie(u).orEmpty() } catch (e: Exception) { "" }

    // ---------- sniffing ----------
    private val skipExt = setOf("ts", "m4s", "key")
    private val junkExt = setOf(
        "js", "mjs", "css", "png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "woff", "woff2", "ttf", "otf", "eot",
        "json", "html", "htm", "php", "asp", "aspx", "map", "xml", "txt", "wasm", "avif", "bmp"
    )
    private val hintRe = Regex("""video|media|stream|manifest|playlist|m3u8|mpd|mime=|master|hls|dash|object/|download|\bmp4\b""", RegexOption.IGNORE_CASE)
    private val probeGate = Semaphore(4)

    fun typeOf(name: String, mime: String?): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext == "m3u8" || ext == "mpd") return "hls"
        val m = mime.orEmpty().lowercase()
        if (m.contains("mpegurl") || m.contains("dash+xml")) return "hls"
        return when (StorageSaver.categoryFor("x.$ext")) {
            StorageSaver.Category.VIDEOS -> "video"
            StorageSaver.Category.MUSIC -> "audio"
            StorageSaver.Category.PHOTOS -> "image"
            StorageSaver.Category.SUBTITLES -> "subtitle"
            StorageSaver.Category.DOCUMENTS -> "document"
            StorageSaver.Category.COMPRESSED -> "compressed"
            StorageSaver.Category.PROGRAMS -> "program"
            StorageSaver.Category.TORRENTS -> "torrent"
            else -> when {
                m.startsWith("video/") -> "video"
                m.startsWith("audio/") -> "audio"
                m.startsWith("image/") -> "image"
                m.contains("vtt") || m.contains("subrip") -> "subtitle"
                else -> "other"
            }
        }
    }

    /** Called for every sub-request a page makes (any thread). */
    private fun sniff(tab: BTab, u: String, headers: Map<String, String>?) {
        if (!u.startsWith("http")) return
        val ext = DirectFiles.extOf(u)
        val isHls = ext == "m3u8" || ext == "mpd"
        if (ext in skipExt) return
        if (isHls || ext in DirectFiles.extensions) { main.post { addFound(tab, u, null, null) }; return }
        // No usable extension (many players serve videos from addresses like /object/v2.abc123): look at what the server says it is.
        if (ext in junkExt) return
        val accept = headers?.entries?.firstOrNull { it.key.equals("Accept", true) }?.value.orEmpty()
        if (accept.startsWith("image/") || accept.contains("text/css") || accept.contains("text/html")) return
        val hasRange = headers?.keys?.any { it.equals("Range", true) } == true
        if (hasRange || hintRe.containsMatchIn(u)) main.post { probe(tab, u, tab.url) }
    }

    private fun probeHeaders(u: String, referer: String, ua: String?): HashMap<String, String> {
        val h = HashMap<String, String>()
        if (referer.startsWith("http")) h["Referer"] = referer
        h["User-Agent"] = ua ?: Net.MOBILE_UA
        cookieFor(u).takeIf { it.isNotEmpty() }?.let { h["Cookie"] = it }
        return h
    }

    private fun accepted(p: com.aven.downloader.net.Probed): Boolean {
        val m = p.mime
        return m.startsWith("video/") || m.startsWith("audio/") || m.contains("mpegurl") || m.contains("dash+xml") ||
            m.contains("vtt") || m.contains("subrip") ||
            (m == "application/octet-stream" && p.size > 1_000_000) ||
            (m.startsWith("application/") && DirectFiles.extOf(p.fileName) in DirectFiles.extensions)
    }

    /** Asks the server what [u] is. @return a Found when it is media or a downloadable file, else null. Used by the Grabber. */
    suspend fun classify(u: String, referer: String, tabId: Int): Found? = withContext(Dispatchers.IO) {
        val p = try { probeGate.withPermit { Net.probe(u, probeHeaders(u, referer, current?.web?.settings?.userAgentString)) } } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { null }
        if (p == null || !accepted(p)) return@withContext null
        val name = p.fileName.ifBlank { Net.fileNameFrom(null, u) }
        Found(p.finalUrl.ifBlank { u }, name, typeOf(name, p.mime), referer, p.mime, tabId)
    }

    /** Asks the server what [u] is; adds it to the lists if it is media or a downloadable file. */
    fun probe(tab: BTab, u: String, referer: String) {
        if (tab.probed.size >= 80 || !tab.probed.add(u)) return
        AvenApp.instance.appScope.launch {
            val f = classify(u, referer, tab.id) ?: return@launch
            main.post { addFound(tab, f.url, f.mime, null, f.name) }
        }
    }

    private fun addFound(tab: BTab, u: String, mime: String?, p: com.aven.downloader.net.Probed?, knownName: String? = null) {
        if (!tab.seen.add(u)) return
        val rawName = knownName?.takeIf { it.isNotBlank() } ?: p?.fileName?.takeIf { it.isNotBlank() } ?: Net.fileNameFrom(null, u)
        val type = typeOf(rawName, mime)
        val f = Found(u, rawName, type, tab.url, mime.orEmpty(), tab.id)
        tab.resources.add(f)
        if (f.isMedia) tab.found.add(f)
    }

    /** A `<video>` source the page itself reports: media even when the URL has no known extension. */
    private fun forceFound(tab: BTab, u: String) {
        if (!tab.seen.add(u)) return
        val name = Net.fileNameFrom(null, u)
        var type = typeOf(name, null)
        if (type == "other" || type == "image") type = "video"
        val f = Found(u, name, type, tab.url, "", tab.id)
        tab.resources.add(f); tab.found.add(f)
    }

    private class Bridge(val tab: BTab) {
        @JavascriptInterface
        fun media(json: String) {
            try {
                val a = JSONArray(json)
                for (i in 0 until a.length()) {
                    val u = a.getString(i)
                    if (u.startsWith("http")) main.post { forceFound(tab, u) }
                }
            } catch (ignored: Exception) { }
        }
    }

    /** Starts (muted) any video/audio on the page so the player requests its real stream address. */
    fun autoPlay() {
        val v = current?.web ?: return
        v.evaluateJavascript(AUTOPLAY_JS, null)
    }

    /**
     * Collects links/images/media from the live page for the Grabber.
     * [cb] gets the definite file links and the "maybe" addresses (resources the page loaded that have no file extension).
     */
    fun collectDom(cb: (List<String>, List<String>) -> Unit) {
        val v = current?.web ?: return cb(emptyList(), emptyList())
        val exts = DirectFiles.extensions.plus(setOf("m3u8", "mpd")).joinToString("|")
        v.evaluateJavascript(collectJs(exts)) { raw ->
            val urls = ArrayList<String>()
            val maybe = ArrayList<String>()
            try {
                val s = JSONArray("[" + (raw ?: "null") + "]").optString(0)
                val o = JSONObject(s)
                o.optJSONArray("u")?.let { a -> for (i in 0 until a.length()) urls.add(a.getString(i)) }
                o.optJSONArray("m")?.let { a -> for (i in 0 until a.length()) maybe.add(a.getString(i)) }
            } catch (ignored: Exception) { }
            cb(urls, maybe)
        }
    }

    private const val MAX_TABS = 20

    private const val AUTOPLAY_JS = """(function(){try{document.querySelectorAll('video,audio').forEach(function(v){try{v.muted=true;var p=v.play();if(p&&p.catch)p.catch(function(){});}catch(e){}});""" +
        """var b=document.querySelector('.vjs-big-play-button,.jw-icon-display,.plyr__control--overlaid,.ytp-large-play-button,.play-button,.btn-play');if(b)b.click();}catch(e){}})();"""

    private const val SCAN_JS = "(function(){if(window.__ahdScan)return;window.__ahdScan=1;" +
        "function scan(){var o=[];document.querySelectorAll('video,audio,source').forEach(function(e){var s=e.currentSrc||e.src;" +
        "if(s&&s.indexOf('http')===0)o.push(s);});if(o.length)AHD.media(JSON.stringify(o));}" +
        "setInterval(scan,2000);scan();})();"

    private fun collectJs(exts: String) = "(function(){var o={},m={};function add(u){if(u&&u.indexOf('http')===0)o[u]=1;}" +
        "document.querySelectorAll('a[href],link[href]').forEach(function(e){add(e.href);});" +
        "document.querySelectorAll('img,video,audio,source,track,embed,iframe,object').forEach(function(e){add(e.currentSrc);add(e.src);add(e.data);add(e.poster);" +
        "var ss=e.getAttribute('srcset');if(ss)ss.split(',').forEach(function(p){try{add(new URL(p.trim().split(' ')[0],location.href).href);}catch(x){}});});" +
        "document.querySelectorAll('[data-src],[data-url],[data-href],[data-video],[data-file]').forEach(function(e){['data-src','data-url','data-href','data-video','data-file'].forEach(function(k){" +
        "var v=e.getAttribute(k);if(v)try{add(new URL(v,location.href).href);}catch(x){}});});" +
        "document.querySelectorAll('meta[property=\"og:video\"],meta[property=\"og:video:url\"],meta[property=\"og:audio\"],meta[property=\"og:image\"]').forEach(function(e){add(e.content);});" +
        "try{var h=document.documentElement.outerHTML.replace(/\\\\\\//g,'/');var re=new RegExp('https?:\\\\/\\\\/[^\"\\'\\\\s<>\\\\\\\\)]+?\\\\.(?:$exts)(?:\\\\?[^\"\\'\\\\s<>\\\\\\\\)]*)?','gi');var r;var n=0;while((r=re.exec(h))&&n++<400)add(r[0]);}catch(x){}" +
        "try{performance.getEntriesByType('resource').forEach(function(e){var t=e.initiatorType;if(t==='video'||t==='audio'||t==='xmlhttprequest'||t==='fetch'||t==='other')m[e.name]=1;});}catch(x){}" +
        "return JSON.stringify({u:Object.keys(o),m:Object.keys(m)});})()"

    // ---------- names ----------
    private val genericBases = setOf("index", "master", "playlist", "video", "videoplayback", "stream", "media", "file", "download", "manifest", "chunklist", "main", "output", "play", "get", "watch", "embed")

    private fun hashLike(base: String): Boolean {
        if (base.isBlank()) return true
        if (base.lowercase() in genericBases) return true
        if (base.length < 18 || base.contains(' ')) return false
        val digits = base.count { it.isDigit() }
        val upper = base.count { it.isUpperCase() }
        val lower = base.count { it.isLowerCase() }
        return (digits >= 3 && (upper + lower) >= 3) || (upper >= 3 && lower >= 3 && base.none { it == '-' || it == '_' || it == '.' } )
    }

    private fun extFromMime(m: String, type: String): String = when {
        m.contains("mp4") && m.startsWith("audio") -> "m4a"
        m.contains("mp4") -> "mp4"
        m.contains("webm") && m.startsWith("audio") -> "weba"
        m.contains("webm") -> "webm"
        m.contains("matroska") -> "mkv"
        m.contains("quicktime") -> "mov"
        m.contains("mpeg") && m.startsWith("audio") -> "mp3"
        m.contains("aac") -> "aac"
        m.contains("ogg") -> "ogg"
        m.contains("mpegurl") || m.contains("dash") -> "mp4"
        m.contains("vtt") -> "vtt"
        m.contains("subrip") -> "srt"
        type == "audio" -> "m4a"
        type == "video" || type == "hls" -> "mp4"
        else -> ""
    }

    private fun sanitize(s: String): String =
        s.replace(Regex("[\\\\/:*?\"<>|\\n\\r\\t]"), " ").replace(Regex("\\s+"), " ").trim().trim('.').take(120)

    /** A readable file name: the real name when it is one, otherwise the title of the page it was found on. */
    fun niceName(f: Found): String {
        val ext = f.name.substringAfterLast('.', "").lowercase()
        val base = f.name.substringBeforeLast('.', f.name)
        val knownExt = ext in DirectFiles.extensions || ext == "m3u8" || ext == "mpd"
        if (knownExt && !hashLike(base) && ext != "m3u8" && ext != "mpd") return f.name
        val title = sanitize(tabs.firstOrNull { it.id == f.tabId }?.title.orEmpty().ifBlank { current?.title.orEmpty() })
        val outExt = when {
            f.type == "hls" -> "mp4"
            knownExt -> ext
            else -> extFromMime(f.mime, f.type)
        }
        val stem = if (title.isNotBlank() && title.lowercase() !in setOf("loading...", "about:blank")) title else sanitize(base).ifBlank { "download" }
        return if (outExt.isNotEmpty()) "$stem.$outExt" else stem
    }

    // ---------- downloading ----------
    fun sourceFor(f: Found, name: String, parts: Int = 0, pageUrl: String = url): DirectSource =
        DirectSource(f.url, name, f.referer.ifBlank { pageUrl }, userAgent(), cookieFor(f.url), parts)

    suspend fun enqueue(f: Found, name: String, parts: Int, size: Long): Long =
        AvenApp.instance.downloads.enqueueDirect(sourceFor(f, name, parts), f.referer.ifBlank { url }, f.type == "hls", size)

    suspend fun probeSize(f: Found): Long = withContext(Dispatchers.IO) {
        try { Net.probe(f.url, sourceFor(f, f.name).headers()).size.coerceAtLeast(0) } catch (e: Exception) { -1L }
    }

    private val metaGate = Semaphore(2)

    /** Resolution and length of a found media file (HLS: read from the playlist; other video: from the file's header). */
    suspend fun meta(f: Found): FoundMeta = withContext(Dispatchers.IO) {
        if (!f.isMedia) return@withContext FoundMeta()
        try {
            metaGate.withPermit {
                val headers = sourceFor(f, f.name).headers()
                if (f.type == "hls") {
                    val req = Net.request(f.url, headers.plus("Accept-Encoding" to "identity"))
                    val text = Net.client.newCall(req).execute().use { r ->
                        r.body?.source()?.let { s -> s.request(96_000); s.buffer.clone().readUtf8() }.orEmpty()
                    }
                    val res = Regex("RESOLUTION=(\\d+)x(\\d+)").findAll(text).map { it.groupValues[1].toInt() to it.groupValues[2].toInt() }
                        .maxByOrNull { it.second }?.let { "${it.first}x${it.second}" }.orEmpty()
                    val dur = Regex("#EXTINF:([0-9.]+)").findAll(text).sumOf { it.groupValues[1].toDoubleOrNull() ?: 0.0 }.toInt()
                    FoundMeta(res, dur)
                } else if (f.type == "video") {
                    // setDataSource can hang on slow servers and can't be cancelled: give it a time limit
                    withTimeoutOrNull(7000) {
                        async(Dispatchers.IO) {
                            val r = MediaMetadataRetriever()
                            try {
                                r.setDataSource(f.url, headers)
                                val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                                val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                                val d = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000
                                FoundMeta(if (w > 0 && h > 0) "${w}x$h" else "", d.toInt())
                            } catch (e: Exception) { FoundMeta() } finally { try { r.release() } catch (ignored: Exception) { } }
                        }.await()
                    } ?: FoundMeta()
                } else FoundMeta()
            }
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { FoundMeta() }
    }
}
