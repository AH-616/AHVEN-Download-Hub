package com.aven.downloader.ui.player

import androidx.activity.compose.BackHandler
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.aven.downloader.engine.MediaInfo
import com.aven.downloader.engine.StreamFormat
import com.aven.downloader.ui.theme.Gold

/** One picture quality the player can switch to. [muxed] = the address already holds picture and sound. */
class PlayQuality(val label: String, val height: Int, val url: String, val muxed: Boolean)

/** One audio track (a language) that can be merged with a picture-only quality. */
class PlayAudio(val label: String, val url: String)

class PlayerSources(
    val qualities: List<PlayQuality>,
    val audios: List<PlayAudio>,
    val headers: Map<String, String>,
    val audioOnly: Boolean = false
)

/** Builds the quality and audio-language lists for the player from a fetched video. */
fun playerSourcesFrom(info: MediaInfo): PlayerSources? {
    val ok = info.formats.filter { !it.url.isNullOrBlank() && it.protocol == "https" }
    val videoOnly = ok.filter { it.hasVideo && !it.hasAudio && it.height > 0 }
    val muxed = ok.filter { it.hasVideo && it.hasAudio && it.height > 0 }
    val audioFormats = ok.filter { !it.hasVideo && it.hasAudio }

    // one audio per language: the best bitrate (m4a first, it merges best with mp4)
    val audios = audioFormats.groupBy { it.language.orEmpty() }.values.mapNotNull { group ->
        val best = group.sortedWith(compareByDescending<StreamFormat> { it.ext == "m4a" || it.ext == "mp4" }.thenByDescending { it.abr }).firstOrNull()
        best?.let { a -> PlayAudio(a.note?.takeIf { it.isNotBlank() } ?: a.language?.takeIf { it.isNotBlank() } ?: "Default", a.url!!) }
    }

    val qualities = ArrayList<PlayQuality>()
    val heights = (videoOnly.map { it.height } + muxed.map { it.height }).distinct().sortedDescending()
    for (h in heights) {
        val vo = videoOnly.filter { it.height == h }
            .sortedWith(compareByDescending<StreamFormat> { it.ext == "mp4" }.thenByDescending { it.tbr }).firstOrNull()
        if (vo != null && audios.isNotEmpty()) {
            qualities += PlayQuality("${h}p", h, vo.url!!, false)
        } else {
            muxed.filter { it.height == h }.maxByOrNull { it.tbr }?.let { qualities += PlayQuality("${h}p", h, it.url!!, true) }
        }
    }
    if (qualities.isEmpty()) return null
    val headers = ok.firstOrNull()?.headers ?: emptyMap()
    return PlayerSources(qualities, audios, headers)
}

/** A file on this phone (a finished download). [raw] is a content/file address or a plain path. */
fun localSources(raw: String, audioOnly: Boolean): PlayerSources {
    val uri = if (raw.startsWith("content:") || raw.startsWith("file:")) raw else "file://$raw"
    return PlayerSources(listOf(PlayQuality("Original", 0, uri, true)), emptyList(), emptyMap(), audioOnly)
}


/** Lets the screen know a player went full-screen (the app hides its bottom bar then). */
object PlayerChrome {
    var fullscreen by mutableStateOf(false)
}

private fun clock(ms: Long): String {
    val sec = (ms / 1000).toInt().coerceAtLeast(0)
    val h = sec / 3600; val m = sec % 3600 / 60; val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

private fun displayName(ctx: Context, uri: Uri): String {
    try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { return it }
        }
    } catch (ignored: Exception) { }
    return uri.lastPathSegment ?: "subtitle"
}

@OptIn(UnstableApi::class)
private fun subtitleConfig(ctx: Context, uri: Uri): MediaItem.SubtitleConfiguration {
    val name = displayName(ctx, uri)
    val l = name.lowercase()
    val mime = when {
        l.endsWith(".vtt") -> MimeTypes.TEXT_VTT
        l.endsWith(".ass") || l.endsWith(".ssa") -> MimeTypes.TEXT_SSA
        l.endsWith(".ttml") || l.endsWith(".xml") || l.endsWith(".dfxp") -> MimeTypes.APPLICATION_TTML
        else -> MimeTypes.APPLICATION_SUBRIP
    }
    return MediaItem.SubtitleConfiguration.Builder(uri)
        .setMimeType(mime).setLanguage("und").setLabel(name)
        .setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
}

/** Decoder choice: 0 = HW (hardware only), 1 = HW+ (hardware first, software if needed), 2 = SW (software only). */
@OptIn(UnstableApi::class)
private fun renderersFor(ctx: Context, mode: Int): DefaultRenderersFactory {
    val selector = MediaCodecSelector { mime, secure, tunnel ->
        val all = MediaCodecSelector.DEFAULT.getDecoderInfos(mime, secure, tunnel)
        when (mode) {
            0 -> all.filter { it.hardwareAccelerated }.ifEmpty { all }
            2 -> all.filter { it.softwareOnly }.ifEmpty { all }
            else -> all
        }
    }
    return DefaultRenderersFactory(ctx)
        .setMediaCodecSelector(selector)
        .setEnableDecoderFallback(true)
        .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
}

private class TrackOpt(val label: String, val group: Tracks.Group, val index: Int, val selected: Boolean)

private fun trackOpts(t: Tracks, type: Int): List<TrackOpt> {
    val out = ArrayList<TrackOpt>()
    var n = 0
    for (g in t.groups) {
        if (g.type != type || !g.isSupported) continue
        for (i in 0 until g.length) {
            n++
            val f = g.getTrackFormat(i)
            val lang = f.language?.takeIf { it.isNotBlank() && it != "und" }?.let { java.util.Locale(it).displayLanguage }
            var label = f.label?.takeIf { it.isNotBlank() } ?: lang ?: "Track $n"
            if (type == C.TRACK_TYPE_AUDIO && f.channelCount > 0) label += "  (${f.channelCount} ch)"
            out += TrackOpt(label, g, i, g.isTrackSelected(i))
        }
    }
    return out
}

/** Full-screen player for a downloaded video or audio file. */
@Composable
fun LocalPlayerScreen(uri: String, title: String, audioOnly: Boolean, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val src = remember(uri) { localSources(uri, audioOnly) }
    Box(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
        AppPlayer(src, Modifier.fillMaxSize(), title = title, onBack = onClose, canRotate = true)
    }
}

/**
 * The app's own player (Media3 ExoPlayer): picture and sound merged from separate streams, quality / audio / subtitle
 * choice (also from a file), speed, loop, zoom (fit / fill / stretch / pinch), night mode, HW / HW+ / SW decoder,
 * rotate, background play, swipe for brightness and volume, double-tap to skip 10 s.
 *
 * [canRotate] = the player owns the whole screen (shows the rotate button and hides the system bars).
 * [onFullscreen] = shows a full-screen button (used by the small player inside Search).
 */
@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AppPlayer(
    src: PlayerSources,
    modifier: Modifier = Modifier,
    title: String? = null,
    onBack: (() -> Unit)? = null,
    onFatal: (String) -> Unit = {},
    canRotate: Boolean = false,
    fullscreen: Boolean = false,
    onFullscreen: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val view = LocalView.current
    val activity = remember(context) { context.findActivity() }
    val cfg = LocalConfiguration.current
    val prefs = remember { context.getSharedPreferences("player", Context.MODE_PRIVATE) }

    val factory = remember(src) {
        DefaultMediaSourceFactory(
            DefaultDataSource.Factory(
                context,
                DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true).setDefaultRequestProperties(src.headers)
            )
        )
    }
    var decoder by remember { mutableIntStateOf(prefs.getInt("decoder", 1)) }
    val exo = remember(src, decoder) { ExoPlayer.Builder(context, renderersFor(context, decoder)).setMediaSourceFactory(factory).build() }

    var qi by remember(src) { mutableIntStateOf(src.qualities.indexOfFirst { it.height in 1..720 }.let { if (it >= 0) it else 0 }) }
    var ai by remember(src) { mutableIntStateOf(src.audios.indexOfFirst { it.label.contains("original", true) }.let { if (it >= 0) it else 0 }) }
    var retries by remember(src) { mutableIntStateOf(0) }
    var speed by remember { mutableFloatStateOf(1f) }
    var loop by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(true) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var resume by remember(src) { mutableLongStateOf(0L) }
    var seeking by remember { mutableStateOf(false) }
    var seekPos by remember { mutableFloatStateOf(0f) }
    var showControls by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf(false) }
    var page by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var tracks by remember { mutableStateOf(Tracks.EMPTY) }
    var extSub by remember(src) { mutableStateOf<Uri?>(null) }
    var zoom by remember { mutableIntStateOf(0) }          // 0 fit, 1 fill (crop), 2 stretch, 3 pinch
    var scale by remember { mutableFloatStateOf(1f) }
    var tx by remember { mutableFloatStateOf(0f) }
    var ty by remember { mutableFloatStateOf(0f) }
    var night by remember { mutableStateOf(false) }
    var bg by remember { mutableStateOf(prefs.getBoolean("bg", false)) }
    var hud by remember { mutableStateOf<String?>(null) }
    var orientTouched by remember { mutableStateOf(false) }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onTracksChanged(t: Tracks) { tracks = t }
            override fun onPlayerError(e: PlaybackException) {
                // try the next lower quality a couple of times before giving up
                if (qi < src.qualities.lastIndex && retries < 2) { retries++; qi++ }
                else if (decoder != 2 && retries < 3) { retries++; decoder = 2 }   // last try: software decoder
                else { error = "Can't play this one (${e.errorCodeName})"; onFatal(error.orEmpty()) }
            }
        }
        exo.addListener(listener)
        onDispose { exo.removeListener(listener); exo.release() }
    }

    // (re)load when the quality, audio, subtitle file or decoder changes, continuing from the same second
    LaunchedEffect(exo, qi, ai, extSub) {
        if (src.qualities.isEmpty()) return@LaunchedEffect
        val q = src.qualities[qi.coerceIn(0, src.qualities.lastIndex)]
        error = null
        val sub = extSub?.let { subtitleConfig(context, it) }
        val item = MediaItem.Builder().setUri(q.url).apply { if (sub != null) setSubtitleConfigurations(listOf(sub)) }.build()
        val video = factory.createMediaSource(item)
        val source = if (q.muxed || src.audios.isEmpty()) video
        else MergingMediaSource(video, factory.createMediaSource(MediaItem.fromUri(src.audios[ai.coerceIn(0, src.audios.lastIndex)].url)))
        exo.setMediaSource(source, resume)
        if (sub != null) {
            exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        }
        exo.prepare()
        exo.playWhenReady = true
    }
    LaunchedEffect(exo, loop) { exo.repeatMode = if (loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF }
    LaunchedEffect(exo, speed) { exo.setPlaybackSpeed(speed) }
    LaunchedEffect(exo) {
        while (true) {
            if (exo.playbackState != Player.STATE_IDLE) {
                if (!seeking) pos = exo.currentPosition.coerceAtLeast(0)
                resume = exo.currentPosition.coerceAtLeast(0)
            }
            dur = exo.duration.coerceAtLeast(0)
            kotlinx.coroutines.delay(300)
        }
    }
    LaunchedEffect(showControls, playing, menu) {
        if (showControls && playing && !menu) { kotlinx.coroutines.delay(3000); showControls = false }
    }
    LaunchedEffect(hud) { if (hud != null) { kotlinx.coroutines.delay(800); hud = null } }

    // hide the system bars when the player owns the screen
    DisposableEffect(canRotate) {
        val w = activity?.window
        if (canRotate && w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            if (canRotate && w != null) WindowCompat.getInsetsController(w, view).show(WindowInsetsCompat.Type.systemBars())
        }
    }
    LaunchedEffect(canRotate) {
        if (!canRotate && orientTouched) { activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; orientTouched = false }
    }
    DisposableEffect(Unit) {
        onDispose {
            activity?.let {
                if (orientTouched) it.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                val lp = it.window.attributes
                if (lp.screenBrightness >= 0f) { lp.screenBrightness = -1f; it.window.attributes = lp }
            }
        }
    }

    // background play: keep going when the app is left (with a small notification), else pause
    DisposableEffect(exo, bg) {
        val owner = activity as? LifecycleOwner
        val obs = LifecycleEventObserver { _, ev ->
            when (ev) {
                Lifecycle.Event.ON_STOP -> {
                    if (bg && exo.isPlaying) {
                        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true).build()
                    } else exo.pause()
                }
                Lifecycle.Event.ON_START ->
                    exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false).build()
                else -> {}
            }
        }
        owner?.lifecycle?.addObserver(obs)
        onDispose { owner?.lifecycle?.removeObserver(obs) }
    }
    LaunchedEffect(bg, playing) {
        if (bg && playing) PlaybackService.start(context, title ?: "Playing") else PlaybackService.stop(context)
    }
    DisposableEffect(Unit) { onDispose { PlaybackService.stop(context) } }

    val pickSub = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? -> if (u != null) extSub = u }
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    var volF by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    var dragLeft by remember { mutableStateOf(true) }

    fun rotate() {
        val a = activity ?: return
        orientTouched = true
        a.requestedOrientation = if (cfg.orientation == Configuration.ORIENTATION_LANDSCAPE) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }
    fun nextZoom() {
        zoom = (zoom + 1) % 4
        scale = 1f; tx = 0f; ty = 0f
        hud = when (zoom) { 0 -> "Fit"; 1 -> "Fill"; 2 -> "Stretch"; else -> "Pinch to zoom" }
    }

    Box(
        modifier.background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { showControls = !showControls },
                    onDoubleTap = { o ->
                        if (o.x < size.width / 2) { exo.seekTo((exo.currentPosition - 10_000).coerceAtLeast(0)); hud = "−10 s" }
                        else { exo.seekTo(exo.currentPosition + 10_000); hud = "+10 s" }
                    }
                )
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { o -> dragLeft = o.x < size.width / 2 },
                    onDragEnd = {},
                    onDragCancel = {}
                ) { _, dy ->
                    val h = size.height.coerceAtLeast(1)
                    if (dragLeft) {
                        activity?.let {
                            val lp = it.window.attributes
                            val cur = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                            lp.screenBrightness = (cur - dy / h * 1.4f).coerceIn(0.02f, 1f)
                            it.window.attributes = lp
                            hud = "Brightness ${(lp.screenBrightness * 100).toInt()}%"
                        }
                    } else {
                        val mx = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        volF = (volF - dy / h * mx * 1.4f).coerceIn(0f, mx.toFloat())
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, volF.toInt(), 0)
                        hud = "Volume ${(volF / mx * 100).toInt()}%"
                    }
                }
            }
            .pointerInput(zoom) {
                if (zoom == 3) detectTransformGestures { _, pan, z, _ ->
                    scale = (scale * z).coerceIn(1f, 5f)
                    if (scale <= 1.01f) { tx = 0f; ty = 0f } else { tx += pan.x; ty += pan.y }
                }
            }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize().graphicsLayer {
                if (zoom == 3) { scaleX = scale; scaleY = scale; translationX = tx; translationY = ty }
            },
            factory = { ctx -> PlayerView(ctx).apply { useController = false; player = exo } },
            update = {
                it.player = exo
                it.resizeMode = when (zoom) {
                    1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            }
        )
        if (night) Box(Modifier.fillMaxSize().background(Color(0x8C140A00)))
        if (src.audioOnly) Icon(Icons.Filled.MusicNote, null, tint = Gold, modifier = Modifier.align(Alignment.Center).size(96.dp))
        if (buffering && error == null) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Gold)
        error?.let { Text(it, Modifier.align(Alignment.Center).padding(24.dp), color = Color.White) }
        hud?.let {
            Text(
                it, color = Color.White, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 56.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xAA000000)).padding(horizontal = 14.dp, vertical = 8.dp)
            )
        }

        if (showControls) {
            Box(
                Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent, Color(0x66000000))))
            ) {
                Row(Modifier.align(Alignment.TopStart).fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
                    if (title != null) Text(title, Modifier.weight(1f).padding(horizontal = 4.dp), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    else Spacer(Modifier.weight(1f))
                    IconButton(onClick = { page = 4; menu = true }) { Icon(Icons.Filled.ClosedCaption, "Subtitles", tint = Color.White) }
                    IconButton(onClick = { nextZoom() }) { Icon(Icons.Filled.AspectRatio, "Zoom", tint = Color.White) }
                    if (canRotate) IconButton(onClick = { rotate() }) { Icon(Icons.Filled.ScreenRotation, "Rotate", tint = Color.White) }
                    if (onFullscreen != null) IconButton(onClick = onFullscreen) {
                        Icon(if (fullscreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen, "Full screen", tint = Color.White)
                    }
                    IconButton(onClick = { page = 0; menu = true }) { Icon(Icons.Filled.MoreVert, "Settings", tint = Color.White) }
                }
                Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { exo.seekTo((exo.currentPosition - 10_000).coerceAtLeast(0)) }) {
                        Icon(Icons.Filled.Replay10, "Back 10 s", tint = Color.White, modifier = Modifier.size(38.dp))
                    }
                    IconButton(onClick = { if (exo.isPlaying) exo.pause() else exo.play() }, modifier = Modifier.size(64.dp)) {
                        Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play / pause", tint = Color.White, modifier = Modifier.size(56.dp))
                    }
                    IconButton(onClick = { exo.seekTo(exo.currentPosition + 10_000) }) {
                        Icon(Icons.Filled.Forward10, "Forward 10 s", tint = Color.White, modifier = Modifier.size(38.dp))
                    }
                }
                Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(clock(if (seeking) seekPos.toLong() else pos), color = Color.White, style = MaterialTheme.typography.labelMedium)
                    Slider(
                        value = if (seeking) seekPos else pos.toFloat().coerceAtMost(dur.coerceAtLeast(1).toFloat()),
                        onValueChange = { seeking = true; seekPos = it },
                        onValueChangeFinished = { exo.seekTo(seekPos.toLong()); pos = seekPos.toLong(); seeking = false },
                        valueRange = 0f..dur.coerceAtLeast(1).toFloat(),
                        colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = Color(0x55FFFFFF)),
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                    )
                    Text(clock(dur), color = Color.White, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }

    if (menu) {
        val audioTracks = trackOpts(tracks, C.TRACK_TYPE_AUDIO)
        val textTracks = trackOpts(tracks, C.TRACK_TYPE_TEXT)
        val textOff = exo.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT) || textTracks.none { it.selected }
        val zoomNames = listOf("Fit", "Fill (crop)", "Stretch", "Pinch / custom")
        val decNames = listOf("HW", "HW+", "SW")
        fun close() { menu = false; page = 0 }
        ModalBottomSheet(onDismissRequest = { close() }) {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(bottom = 28.dp)) {
                when (page) {
                    0 -> {
                        if (src.qualities.size > 1) MenuRow("Quality", src.qualities[qi.coerceIn(0, src.qualities.lastIndex)].label) { page = 1 }
                        if (src.audios.size > 1 || audioTracks.size > 1) MenuRow("Audio track", audioTracks.firstOrNull { it.selected }?.label ?: src.audios.getOrNull(ai)?.label ?: "Default") { page = 2 }
                        MenuRow("Subtitles", if (textOff) "Off" else textTracks.firstOrNull { it.selected }?.label ?: "On") { page = 4 }
                        MenuRow("Playback speed", "${speed}x") { page = 3 }
                        MenuRow("Video zoom", zoomNames[zoom]) { page = 5 }
                        MenuRow("Decoder", decNames[decoder]) { page = 6 }
                        MenuRow("Night mode", if (night) "On" else "Off") { night = !night }
                        MenuRow("Background play", if (bg) "On" else "Off") { bg = !bg; prefs.edit().putBoolean("bg", bg).apply() }
                        MenuRow("Loop video", if (loop) "On" else "Off") { loop = !loop }
                    }
                    1 -> src.qualities.forEachIndexed { i, q -> PickRow(q.label, i == qi) { retries = 0; qi = i; close() } }
                    2 -> {
                        if (src.audios.size > 1) src.audios.forEachIndexed { i, a -> PickRow(a.label, i == ai) { ai = i; close() } }
                        else audioTracks.forEach { t ->
                            PickRow(t.label, t.selected) {
                                exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                                    .setOverrideForType(TrackSelectionOverride(t.group.mediaTrackGroup, t.index)).build()
                                close()
                            }
                        }
                    }
                    3 -> listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f).forEach { v -> PickRow("${v}x", v == speed) { speed = v; close() } }
                    4 -> {
                        PickRow("Off", textOff) {
                            exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                            close()
                        }
                        textTracks.forEach { t ->
                            PickRow(t.label, t.selected && !textOff) {
                                exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                    .setOverrideForType(TrackSelectionOverride(t.group.mediaTrackGroup, t.index)).build()
                                close()
                            }
                        }
                        MenuRow("Load from file…", ".srt  .vtt  .ass") { close(); pickSub.launch(arrayOf("*/*")) }
                    }
                    5 -> zoomNames.forEachIndexed { i, n -> PickRow(n, i == zoom) { zoom = i; scale = 1f; tx = 0f; ty = 0f; close() } }
                    else -> {
                        decNames.forEachIndexed { i, n ->
                            PickRow(
                                when (i) { 0 -> "HW  (hardware only)"; 1 -> "HW+  (hardware, software if needed)"; else -> "SW  (software only)" }, i == decoder
                            ) { if (i != decoder) { decoder = i; prefs.edit().putInt("decoder", i).apply() }; close() }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuRow(title: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
        Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun PickRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = if (selected) Gold else MaterialTheme.colorScheme.onSurface, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
        if (selected) Text("✓", color = Gold)
    }
}
