package com.aven.downloader.ui.player

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.ui.PlayerView
import com.aven.downloader.engine.MediaInfo
import com.aven.downloader.engine.StreamFormat
import com.aven.downloader.ui.theme.Gold

/** One picture quality the player can switch to. [muxed] = the address already holds picture and sound. */
class PlayQuality(val label: String, val height: Int, val url: String, val muxed: Boolean)

/** One audio track (a language) that can be merged with a picture-only quality. */
class PlayAudio(val label: String, val url: String)

class PlayerSources(
    val qualities: List<PlayQuality>,
    val audios: List<PlayAudio>,
    val headers: Map<String, String>,
    val audioOnly: Boolean = false
)

/** Builds the quality and audio-language lists for the player from a fetched video. */
fun playerSourcesFrom(info: MediaInfo): PlayerSources? {
    val ok = info.formats.filter { !it.url.isNullOrBlank() && it.protocol == "https" }
    val videoOnly = ok.filter { it.hasVideo && !it.hasAudio && it.height > 0 }
    val muxed = ok.filter { it.hasVideo && it.hasAudio && it.height > 0 }
    val audioFormats = ok.filter { !it.hasVideo && it.hasAudio }

    // one audio per language: the best bitrate (m4a first, it merges best with mp4)
    val audios = audioFormats.groupBy { it.language.orEmpty() }.values.mapNotNull { group ->
        val best = group.sortedWith(compareByDescending<StreamFormat> { it.ext == "m4a" || it.ext == "mp4" }.thenByDescending { it.abr }).firstOrNull()
        best?.let { a -> PlayAudio(a.note?.takeIf { it.isNotBlank() } ?: a.language?.takeIf { it.isNotBlank() } ?: "Default", a.url!!) }
    }

    val qualities = ArrayList<PlayQuality>()
    val heights = (videoOnly.map { it.height } + muxed.map { it.height }).distinct().sortedDescending()
    for (h in heights) {
        val vo = videoOnly.filter { it.height == h }
            .sortedWith(compareByDescending<StreamFormat> { it.ext == "mp4" }.thenByDescending { it.tbr }).firstOrNull()
        if (vo != null && audios.isNotEmpty()) {
            qualities += PlayQuality("${h}p", h, vo.url!!, false)
        } else {
            muxed.filter { it.height == h }.maxByOrNull { it.tbr }?.let { qualities += PlayQuality("${h}p", h, it.url!!, true) }
        }
    }
    if (qualities.isEmpty()) return null
    val headers = ok.firstOrNull()?.headers ?: emptyMap()
    return PlayerSources(qualities, audios, headers)
}

/** A file on this phone (a finished download). [raw] is a content/file address or a plain path. */
fun localSources(raw: String, audioOnly: Boolean): PlayerSources {
    val uri = if (raw.startsWith("content:") || raw.startsWith("file:")) raw else "file://$raw"
    return PlayerSources(listOf(PlayQuality("Original", 0, uri, true)), emptyList(), emptyMap(), audioOnly)
}

private fun clock(ms: Long): String {
    val sec = (ms / 1000).toInt().coerceAtLeast(0)
    val h = sec / 3600; val m = sec % 3600 / 60; val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

/** Full-screen player for a downloaded video or audio file. */
@Composable
fun LocalPlayerScreen(uri: String, title: String, audioOnly: Boolean, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val src = remember(uri) { localSources(uri, audioOnly) }
    Box(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
        AppPlayer(src, Modifier.fillMaxSize(), title = title, onBack = onClose)
    }
}

/**
 * The app's own player (Media3 ExoPlayer): picture and sound merged from separate streams, quality and audio-language
 * choice, speed, loop. Controls are drawn over the picture without a solid background.
 */
@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AppPlayer(src: PlayerSources, modifier: Modifier = Modifier, title: String? = null, onBack: (() -> Unit)? = null, onFatal: (String) -> Unit = {}) {
    val context = LocalContext.current
    val factory = remember(src) {
        DefaultMediaSourceFactory(
            DefaultDataSource.Factory(
                context,
                DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true).setDefaultRequestProperties(src.headers)
            )
        )
    }
    val exo = remember(src) { ExoPlayer.Builder(context).setMediaSourceFactory(factory).build() }

    var qi by remember(src) { mutableIntStateOf(src.qualities.indexOfFirst { it.height in 1..720 }.let { if (it >= 0) it else 0 }) }
    var ai by remember(src) { mutableIntStateOf(src.audios.indexOfFirst { it.label.contains("original", true) }.let { if (it >= 0) it else 0 }) }
    var retries by remember(src) { mutableIntStateOf(0) }
    var speed by remember { mutableFloatStateOf(1f) }
    var loop by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(true) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var seeking by remember { mutableStateOf(false) }
    var seekPos by remember { mutableFloatStateOf(0f) }
    var showControls by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf(false) }
    var page by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var firstLoad by remember(src) { mutableStateOf(true) }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlayerError(e: PlaybackException) {
                // try the next lower quality a couple of times before giving up
                if (qi < src.qualities.lastIndex && retries < 2) { retries++; qi++ }
                else { error = "Can't play this one (${e.errorCodeName})"; onFatal(error.orEmpty()) }
            }
        }
        exo.addListener(listener)
        onDispose { exo.removeListener(listener); exo.release() }
    }

    // (re)load when the quality or audio changes, continuing from the same second
    LaunchedEffect(src, qi, ai) {
        if (src.qualities.isEmpty()) return@LaunchedEffect
        val q = src.qualities[qi.coerceIn(0, src.qualities.lastIndex)]
        val start = if (firstLoad) 0L else exo.currentPosition
        firstLoad = false
        error = null
        val video = factory.createMediaSource(MediaItem.fromUri(q.url))
        val source = if (q.muxed || src.audios.isEmpty()) video
        else MergingMediaSource(video, factory.createMediaSource(MediaItem.fromUri(src.audios[ai.coerceIn(0, src.audios.lastIndex)].url)))
        exo.setMediaSource(source, start)
        exo.prepare()
        exo.playWhenReady = true
    }
    LaunchedEffect(loop) { exo.repeatMode = if (loop) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF }
    LaunchedEffect(speed) { exo.setPlaybackSpeed(speed) }
    LaunchedEffect(exo) {
        while (true) {
            if (!seeking) pos = exo.currentPosition.coerceAtLeast(0)
            dur = exo.duration.coerceAtLeast(0)
            kotlinx.coroutines.delay(300)
        }
    }
    LaunchedEffect(showControls, playing, menu) {
        if (showControls && playing && !menu) { kotlinx.coroutines.delay(3000); showControls = false }
    }

    Box(
        modifier.background(Color.Black).clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { showControls = !showControls }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx -> PlayerView(ctx).apply { useController = false; player = exo } },
            update = { it.player = exo }
        )
        if (src.audioOnly) Icon(Icons.Filled.MusicNote, null, tint = Gold, modifier = Modifier.align(Alignment.Center).size(96.dp))
        if (buffering && error == null) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Gold)
        error?.let { Text(it, Modifier.align(Alignment.Center).padding(24.dp), color = Color.White) }

        if (showControls) {
            Box(
                Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent, Color(0x66000000))))
            ) {
                Row(Modifier.align(Alignment.TopStart).fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
                    if (title != null) Text(title, Modifier.weight(1f).padding(horizontal = 4.dp), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    else Spacer(Modifier.weight(1f))
                    IconButton(onClick = { page = 0; menu = true }) { Icon(Icons.Filled.MoreVert, "Settings", tint = Color.White) }
                }
                Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { exo.seekTo((exo.currentPosition - 10_000).coerceAtLeast(0)) }) {
                        Icon(Icons.Filled.Replay10, "Back 10 s", tint = Color.White, modifier = Modifier.size(38.dp))
                    }
                    IconButton(onClick = { if (exo.isPlaying) exo.pause() else exo.play() }, modifier = Modifier.size(64.dp)) {
                        Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play / pause", tint = Color.White, modifier = Modifier.size(56.dp))
                    }
                    IconButton(onClick = { exo.seekTo(exo.currentPosition + 10_000) }) {
                        Icon(Icons.Filled.Forward10, "Forward 10 s", tint = Color.White, modifier = Modifier.size(38.dp))
                    }
                }
                Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(clock(if (seeking) seekPos.toLong() else pos), color = Color.White, style = MaterialTheme.typography.labelMedium)
                    Slider(
                        value = if (seeking) seekPos else pos.toFloat().coerceAtMost(dur.coerceAtLeast(1).toFloat()),
                        onValueChange = { seeking = true; seekPos = it },
                        onValueChangeFinished = { exo.seekTo(seekPos.toLong()); pos = seekPos.toLong(); seeking = false },
                        valueRange = 0f..dur.coerceAtLeast(1).toFloat(),
                        colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = Color(0x55FFFFFF)),
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                    )
                    Text(clock(dur), color = Color.White, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }

    if (menu) {
        ModalBottomSheet(onDismissRequest = { menu = false; page = 0 }) {
            Column(Modifier.fillMaxWidth().padding(bottom = 28.dp)) {
                when (page) {
                    0 -> {
                        if (src.qualities.size > 1) MenuRow("Quality", src.qualities[qi.coerceIn(0, src.qualities.lastIndex)].label) { page = 1 }
                        if (src.audios.size > 1) MenuRow("Audio", src.audios[ai.coerceIn(0, src.audios.lastIndex)].label) { page = 2 }
                        MenuRow("Playback speed", "${speed}x") { page = 3 }
                        MenuRow("Loop video", if (loop) "On" else "Off") { loop = !loop }
                    }
                    1 -> src.qualities.forEachIndexed { i, q -> PickRow(q.label, i == qi) { retries = 0; qi = i; menu = false; page = 0 } }
                    2 -> src.audios.forEachIndexed { i, a -> PickRow(a.label, i == ai) { ai = i; menu = false; page = 0 } }
                    else -> listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { v -> PickRow("${v}x", v == speed) { speed = v; menu = false; page = 0 } }
                }
            }
        }
    }
}

@Composable
private fun MenuRow(title: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
        Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PickRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = if (selected) Gold else MaterialTheme.colorScheme.onSurface, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
        if (selected) Text("✓", color = Gold)
    }
}
