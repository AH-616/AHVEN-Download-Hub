# AHD Hub (AHVEN Download Hub)

Standalone Android app (separate from AHVEN) that downloads video/audio from **YouTube, Facebook, Instagram, TikTok and every other site yt-dlp supports**
with a real engine (yt-dlp + FFmpeg via `io.github.junkfood02.youtubedl-android` 0.18.1).

Features: paste / Share-menu links, in-app preview player (Media3 ExoPlayer) before downloading, only the
qualities that really exist, video or MP3/M4A audio, queue with 1-5 concurrent downloads, progress/speed/size,
pause/resume/cancel/retry, persistent history (Room), tap a finished download -> "Open with" chooser
(VLC, MX Player, ...), settings (quality, format, folder, Wi-Fi only, duplicates, notifications, diagnostics, yt-dlp update).

> **Status:** this project could NOT be compiled or run in the environment where it was written (Maven/Gradle
> downloads were blocked). The first GitHub Actions build is the first real compile. If it fails, copy the
> error from the log and send it back - it is normally a one-line fix. Real YouTube/Facebook downloads are
> untested until you try them on a phone.

## Build the APK on your phone (GitHub Actions)

You only need a free GitHub account and a mobile browser (Chrome, "Desktop site" ON makes it easier).

**Option A - easiest from a phone: upload the ZIP itself**
1. github.com -> **+** -> **New repository** (name e.g. `aven-downloader`, Private is fine) -> Create.
2. **Add file -> Create new file**. Name it `.github/workflows/build.yml` (typing the `/` makes the folders).
   Paste the contents of the `.github/workflows/build.yml` file from this ZIP. Commit.
3. **Add file -> Upload files**. Upload this ZIP **as it is** (do not unzip). Commit.
   (The workflow detects the ZIP, unzips it and builds it.)
4. Open the **Actions** tab -> the run **Build AHD Hub APK**. Wait about 8-15 minutes (first run is slowest).
5. Every successful build is also published automatically under the repo's **Releases** tab (tag `build-N`) with the 3 APKs - download from there. (Artifacts are still attached to the run.)

**Option B - normal repository (PC / Termux / extracted files)**
Upload the extracted project so that `settings.gradle.kts` and `.github/` are in the repository root, then follow steps 4-5.

If the run is red: open it, click the failed step, copy the red error text and send it to me.

## Which APK to install

| File | Use for |
|---|---|
| `app-arm64-v8a-debug.apk` | almost all modern phones (recommended) |
| `app-armeabi-v7a-debug.apk` | old 32-bit phones |
| `app-universal-debug.apk` | works on both, bigger |

x86 emulators are not supported (to keep the APK smaller). Installing needs "Install unknown apps" permission.
All builds use the same fixed debug key, so a newer build installs over an older one.

## Using the app
* **Share popup**: in YouTube/Instagram/TikTok/etc. choose Share -> AHD Hub. A small popup opens over that app
  (not the full app): pick Video/Audio, quality (and audio language when the video has several), tap Download.
  It runs in the background; progress shows in the notification.
* **Playlists**: a playlist link opens the popup with a video list. Choose quality, tick videos (or First 10/20/25/All),
  see the estimated total size for the selected videos only (estimate = length x typical bitrate), Download.
* **Copied link**: Android 10+ does not let apps watch the clipboard in the background, so a popup cannot open by itself
  when you copy. Instead: add the **Download link** Quick Settings tile (or long-press the app icon -> *Download copied link*).
  Copy a link, tap the tile, the popup opens with that link.
* **Home**: paste a link (Paste button) -> Preview (in-app player), choose quality, Download. Playlist links open the popup.
* **Downloads**: queue, progress, pause/resume, cancel, retry, history. Tap a finished item -> Open with.
* **Settings**: concurrent downloads 1-5, Wi-Fi only, folder, duplicates, notifications, automatic yt-dlp update,
  player-client fallback / IPv4, optional login cookies.

## Google Drive
* **Single file** (video, zip, pdf, apk ... any file shared as "Anyone with the link"): downloaded by the app's own
  multi-connection downloader (HTTP Range). Downloads view shows boxes (one per block) and one row per connection
  (done / left / speed). If a Drive *video's* original file can't be fetched, the app falls back to yt-dlp.
* **Google Docs / Sheets / Slides**: pick a format (Docs PDF/DOCX/TXT, Sheets XLSX/PDF/CSV, Slides PPTX/PDF).
* **Folder**: yt-dlp first; if its folder reader fails (error `expected string or bytes-like object`), a simple page
  reader lists the files. Try Settings -> Update channel -> Nightly + Update engine too.
* Private files: Settings -> Login cookies -> Google Drive. Quota limits ("downloaded too many times") are Google's.
* Untested against the live Drive site; Google may throttle many connections (default 4 parts; lower it if you see 403/429).

## Speed
* Settings -> **Number of parts** (1-16, default 4): parts of one download fetched at the same time.
  Drive files: that many connections. HLS/DASH videos (Facebook, Instagram...): that many fragments at once.
  YouTube with more than 4 parts also uses 10 MB chunks.
* Settings -> **Auto-detect copied link**: when the app opens it reads a copied video link. (Android shows its own "pasted" notice.)
* Link info is cached for 10 minutes; YouTube title+picture show immediately.

## Storage folders
Inside the folder you choose (or Downloads/AHD Hub) files are sorted into Videos, Music, Photos, Documents, Compressed,
Programs, Subtitles, Torrents, Others. Choosing a folder creates these (empty) folders at once. The default
Downloads/AHD Hub location creates a folder when the first file of that type arrives.

## Updates (in-app)
* Set the repository **variable** `UPDATE_REPO` = `owner/public-repo` and the **secret** `RELEASE_TOKEN` (fine-grained token,
  Contents: read/write on that public repo). Builds then publish their Release (name "AHD Hub v1.N", tag `build-N`,
  3 APKs) into the public repo, and the app checks that repo's latest release.
* A new version can be postponed for at most 2 days; from day 3 the app shows "Update required" and the old version stops working.
* Optional repository variable `USE_R8` = `true` builds the shrunk/obfuscated release APK. Untested: if that APK crashes, remove the variable.

## Size estimates
Shown sizes use the same stream the download will pick (MP4: H.264 + M4A; MKV: newest codec); MP3 size follows the video
length. The exact stream ids that were measured are pinned for the download (shown as "Format ids" on the card). Playlist sizes are rough (length x typical bitrate). They are estimates, the real file can differ.

## Signing with your own key (optional)
Add repository Secrets `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` and builds are signed with your key
(see `.github/workflows/build.yml`). Without them the built-in debug key is used.

## YouTube troubleshooting (honest)
YouTube blocks many app/server/VPN IP addresses ("Sign in to confirm you're not a bot", 403, 429). The app
auto-updates yt-dlp daily, tries several YouTube player clients in turn and forces IPv4. If it still fails:
switch between Wi-Fi and mobile data (or turn VPN off), wait a while after 429, update yt-dlp in Settings, and as a
last resort sign in under Settings -> Login cookies (use a spare Google account: automated use can get an account limited).
This cannot be guaranteed to work for every network.

## Later integration with AHVEN (not implemented yet)
AHVEN can open the popup with either
* `Intent(ACTION_VIEW, Uri.parse("ahven://download?url=" + Uri.encode(link)))` (`aven://` also works), or
* an explicit intent to `com.aven.downloader/.ui.quick.QuickDownloadActivity` with extra `com.aven.downloader.extra.URL`.

## Limits (honest list)
* Playlist size is an estimate. DRM-protected or login-only videos fail unless you add cookies; no DRM bypass.
* "Pause" stops yt-dlp and keeps the partial file; Resume continues from it (yt-dlp has no live pause).
* yt-dlp breaks when sites change; update it from Settings.
* YouTube needs a JavaScript runtime in yt-dlp; the library's bundled QuickJS (0.18.1) is used for that.

## License
GPL-3.0 (the yt-dlp Android library is GPL-3.0). See `LICENSE`. Not affiliated with YTDLnis; no YTDLnis code is copied.
